function y = vl_compNormSimiMatrix(x,dzdy)

[r,d,nimg] = size(x); % each row represents feature vector of a super-pixel.
eps = 1e-5;

% This function compute the similarity matrix of super-pixels 
%if nargin <= 2
  y = gpuArray(double(zeros(r, r, nimg)));
  vones = gpuArray(double(ones(r,1)));
    for l = 1 : nimg      
     simi = squeeze(x(:, :, l));
     D = 1 ./ max(sum(simi, 2), eps);
     if nargin <= 1
        y(:,:,l) = diag(D) * simi;  % D^(-1) * W         
     else      
        %y(:,:,l) = diag(D) * dzdy - vones * diag(diag(D).^2 * simi * dzdy')'; 
        y(:,:,l) = diag(D) * dzdy - diag(diag(D).^2 * simi * dzdy') * vones'; 
     end
  end
%else
  % to do: compute the gradient efficiently
  
    
%end
