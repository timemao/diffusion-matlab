function onehot_lab = label2onehot(lab, nlabels)
[r,c] = size(lab);
onehot_lab = zeros([r*c, nlabels]);
for k = 1 : nlabels
   idx = find(lab == k);
   onehot_lab(idx, k) = 1;  
end