function [iLabels_spect, iLabels_filt, res_eigs] = GenerateInitalLabels_Spect(imgpath, net0, posi_lbs)
img = imread(imgpath); 
nCls = 21;

% sepectral clustering
[res_spet, res_eigs] = cnn_diffMap_apply(img, net0,  size(posi_lbs, 1)+ 2, 1); %length(unique(posi_lbs(:, 3)))
re = zeros(size(res_eigs.data.labels));
lbs = unique(res_eigs.data.labels(:));
nSPs = size(res_eigs.eig.V, 1);

% extract the initial labels based on clusters of spectral clustering 
iLabels_spect = zeros(prod(size(res_spet)), nCls);
iLabels_spect(:, 1) = 1;
for k = 1 : size(posi_lbs, 1)
    posi = posi_lbs(k, :);
    cls = posi(3) + 1;
    idSP = res_spet(round(posi(1)) + 1, round(posi(2)) + 1);
    idxSet = find(res_spet == idSP);
    iLabels_spect(idxSet, cls) = 1;
    iLabels_spect(idxSet, 1) = 0;
    %idSeg(cls) = idSeg(cls) + ;
end
iLabels_spect = reshape(iLabels_spect, [size(res_spet), nCls]);
[~, lbs_spect] = max(iLabels_spect, [] ,3);
close all;

figure, subplot(1,4,1); imagesc((img));
hold on, subplot(1,4,2); imagesc(lbs_spect);

% filtering by spectral bases

diffDist = res_eigs.diffDist;
%Simi = exp(-1e+9 * diffDist);
Simi = diffDist; %res_eigs.simi; %diffDist;


accu_points = zeros(1, 21);
lab_perPixel_seeds = ones(nSPs, 1);
lab_filtered = zeros(nSPs, nCls);

for k = 1 : size(posi_lbs, 1)
    idSeg = res_eigs.data.labels(round(posi_lbs(k, 1)), round(posi_lbs(k, 2)));
    lab_perPixel_seeds(idSeg) = posi_lbs(k, 3) + 1;
    accu_points(posi_lbs(k, 3) + 1) = accu_points(posi_lbs(k, 3) + 1) + 1;
    
    %try
    lab_filtered(:, posi_lbs(k,3) + 1) = max(lab_filtered(:, posi_lbs(k,3) + 1),Simi(idSeg, :)');
end
lab_perPixel_coarse = lab_perPixel_seeds;    

if(0)
    re2 = zeros(size(res_eigs.data.labels));
    for ll = 1 : length(lbs)
       re2(find(res_eigs.data.labels == ll)) = gather(lab_perPixel_coarse(ll));
    end
    figure, imagesc(re2);
end


%nSimi = diag(1 ./ (sum(Simi, 2))) * Simi;
%[eig2.U, eig2.Gamma, eig2.V] = svd(nSimi);

nlabels = 21;
onehot_lab = label2onehot(lab_perPixel_coarse, nlabels);
%lab_filtered =  Simi * reshape(onehot_lab, [], nlabels); %Simi
lab_filtered(:, 1) = 0.7; %lab_filtered(:, 1) / (nSPs - size(posi_lbs, 1)) * 1.0;
for k = 2 : size(lab_filtered, 2)
   if accu_points(k) > 0
     lab_filtered(:, k) = lab_filtered(:, k) ;%/ accu_points(k);
   end
end

[~, lab] = max(lab_filtered, [], 2);
re3 = zeros([prod(size(res_eigs.data.labels)), nCls]);
for idcls = 1 : 21
    for ll = 1 : length(lbs)
       re3(find(res_eigs.data.labels == ll), idcls) = gather(lab_filtered(ll, idcls));
    end
end

%figure, imagesc(re3);
[r,c] = size(res_eigs.data.labels);
iLabels_filt = reshape(re3, r, c, []);
[~, lbs_filt] = max(iLabels_filt, [] ,3);
 
hold on, subplot(1,4,3); imagesc(lbs_filt);

re4 = zeros(size(res_eigs.data.labels));
for ll = 1 : length(lbs)
   re4(find(res_eigs.data.labels == ll)) = gather(lab_perPixel_seeds(ll));
end
hold on, subplot(1,4,4); imagesc(re4);
