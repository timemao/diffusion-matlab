function [spect] = cnn_diffMap_apply_v1(img, net, ns, isdeep, labels)

% substract the mean from the input image
mean_img = [122.6769, 116.67, 104.0102];
mean_img = reshape(mean_img, 1,1,3);
im = bsxfun(@minus,double(img),mean_img);

% first step: compute supper-pxiels
if nargin < 5
    [labels, numlabels] = slicmex(img,600,20);
    [labels, numlabels] = aggrSegms(img, labels);
end
[neig_mask] = getNeigSegmsMask(labels);

% second step: construct the input data structure in gpu
data.labels = gpuArray(single(labels));
nSegs = length(unique(data.labels(:)));
data.im = gpuArray(single(im));
data.imorig = img;

[r,c,d] = size(data.im);
idx = [4 : 8 : r-4]';
idy = [4 : 8 : c-4];
data.coor = gpuArray(single([reshape(repmat(idx, 1, length(idy)), 1, []); reshape(repmat(idy, length(idx), 1), 1, [])]));
data.neighMask = neig_mask; %gpuArray(single(ones(nSegs, nSegs)));
% Perform net inference on the input data
res = vl_mysimplenn_diffMap(net, data, [], [], 'disableDropout', 1); %,  'conserveMemory', 'true');    
diffDist = ((res(end).x)); %????? end-1
spect.simi = res(33).x;

% do spectrual clustering after having the spectrals 
if isdeep
    ly_simi = 26 + 7;
    ly_eig = 35; %40; %28 + 7;
else
    ly_simi = 26 + 0 ;
    ly_eig = 28 + 0 ;
end
%mat_simi = exp(-1e+9 * res(ly_simi + 3).x);
mat_simi = res(38).x; %ly_simi + 5
mat_eig = res(ly_eig+1).x{1}.eig;

spect.eig = mat_eig;
spect.simi = mat_simi;
spect.data = data;
spect.diffDist = gather(res(end-1).x); %%%????
% return back the result

if(0)
    re = zeros(size(data.labels));
    lbs = unique(data.labels(:));
    for ll = 1 : length(lbs)
       re(find(data.labels == ll)) = gather(spect.diffDist(250, ll));
    end
    re;figure, imagesc(re),figure, imshow(uint8(127 + data.im))
end
%