function [data] = getBatch_weakSup(imdb,batch)

  for i = 1: length(batch)
    %load(imdb.img_names{batch(i)}); % 'labels', 'numlabels', 'img', 'groundTruth'    
   % rgbPath = sprintf(imdb.paths.image, imdb.images.name{batch(i)}) ;
   % rgb = vl_imreadjpeg({rgbPath}) ;
   % img = rgb{1} ;
    
    %labelsPath = sprintf(imdb.paths.classSegmentation, imdb.images.name{batch(i)}) ;
    %label_gt = imread(labelsPath) ;
    load(imdb.images.Labels{batch(i)});
   
   % if(size(img, 3) == 1)
   %     img = repmat(img, 1, 1, 3);
   % end
   % [H, W, d] = size(img);
    
    %mid = randi(length(gts));
    %cind = find(H==imdb.imsizes(:,1)&W==imdb.imsizes(:,2));
    %coor = imdb.coords{cind};
    %mask = double(gts{mid}.Segmentation);
    
    %[diffDist, prob] = mask2diffDist(mask, labels);
    
    %mask_tmp_final = zeros(length(unique(imdb.coords{cind}(1,:))),length(unique(imdb.coords{cind}(2,:))));
    %mask_tmp = groundTruth{mid}.Segmentation;
    %mask_tmp_final = reshape(mask_tmp(sub2ind([H,W],imdb.coords{cind}(1,:),imdb.coords{cind}(2,:))), size(mask_tmp_final));
  end  
  
  % subtract average
  %if isfield(imdb,'mean_image')
  %  im = bsxfun(@minus,double(img),imdb.mean_image);
  %end
  % img_names = imdb.img_names(batch);
  %nc = max(mask(:));
  %ns = size(mask, 1);
  %code = zeros(ns, nc);
  %code(sub2ind([ns, nc], [ones(ns, 1), mask(:)])) = 1;
  
  %data.im = gpuArray(single(im));
  %data.mask = gpuArray(single(prob));
  %data.diffDist = gpuArray(single(diffDist));
  %data.labels = gpuArray(single(labels));
  %data.coor = gpuArray(single(coor));
  %data.neighMask = gpuArray(single(ones(size(neig_mask))));
 
end