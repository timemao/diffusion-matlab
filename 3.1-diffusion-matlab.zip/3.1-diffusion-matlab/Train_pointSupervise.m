%% This function learn for semantic segmentation with the weak point-wise supervision
close all

nCls = 21;
addpath('/home/jian/download_projects/matconvnet-fcn-master/')
addpath('/home/jian/download_projects/whats-the-point1-master/whats_the_point/whats_the_point/data/');
addpath(genpath('./'))
run('/home/jian/download_projects/matconvnet-1.0-beta24/matlab/vl_setupnn.m');
addpath(genpath('/home/jian/download_projects/matconvnet-1.0-beta24/examples'));
addpath('/home/jian/download_projects/vlfeat-master/toolbox');

%% Step 1: generate the initial labels given the weak point-wise supervisions
%load('/home/jian/Projects/DiffusionMapLearning/data/exp_bake8/net-epoch-100.mat');
load('/home/jian/Projects/DiffusionMapLearning/data/exp/net-epoch-102.mat');
net.layers(end) = [];
net.layers{41}.weights{2} = 10
net.layers{end}.weights{1} = 1e+4;
if(0)
    net.layers(end) = [];
    net.layers{end+1} = struct('type', 'neighMasking_v2');
    net.layers{end+1} = struct('type', 'compNormSimiMatrix');
    net.layers{end+1} = struct('type', 'compEigDecomp');
    net.layers{end+1} = struct('type', 'compDiffDist');
    net = vl_simplenn_move(net, 'gpu');
end

net0 = net;
net0 = vl_simplenn_move(net0, 'gpu');

%%%%%%%%%%%%
%load point labels
load('./data/points_labels.mat', 'Points_trainval', 'Points_supp', 'IDs_supp', 'IDs_trainval');
folderpath = '/media/jian/oldsystem/home/jian/Database/VOC/VOC2012/VOCdevkit/VOC2012/JPEGImages/';
foldersegm_gt = '/media/jian/oldsystem/home/jian/Database/VOC/VOC2012/VOCdevkit/VOC2012/SegmentationClass/';
Prob_spect = [];
Prob_filt = [];

%net0.layers(33) = [];
list_file = dir(foldersegm_gt);
pr = [];
%for k =2218: length(IDs_trainval)
for k = 50 : length(list_file)
    imid = find(strcmp(IDs_trainval, list_file(k).name(1 : end-4)));
    
    %k
    %imid = k;
    imgpath = [folderpath, IDs_trainval{imid}, '.jpg'];
    posi_lbs = [];
    for tt = 1 : length(Points_trainval{imid})
        posi_lbs = [posi_lbs; [Points_trainval{imid}{tt}.y, Points_trainval{imid}{tt}.x, Points_trainval{imid}{tt}.cls]];
    end
    %%%%%%%%%%%%
    %% load ground-truth segmentation labels
    igt_seg = [foldersegm_gt, IDs_trainval{imid}, '.png'];
   
    
     try
       [segMap,map] = imread(igt_seg);
     catch
        segMap = [];
     end
    
     if ~isempty(segMap)
         segMap;
     end
    %imgpath = '/media/jian/oldsystem/home/jian/Database/Saliency/BenchmarkIMAGES/BenchmarkIMAGES/i40.jpg';
    %imgpath = '/media/jian/oldsystem/home/jian/Database/BSR/BSDS500/data/images/train_all/112082.jpg';
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% Ours
    if ~isempty(posi_lbs)
        img = imread(imgpath); %2007_000175
        [iLabels_spect, iLabels_filt, eigs_info] = GenerateInitalLabels_Spect(imgpath, net0, posi_lbs);

        Prob_spect{k} = iLabels_spect; % ./ repmat(sum(iLabels_spect, 3), 1, 1, nCls);
        Prob_filt{k} = iLabels_filt; % ./ repmat(sum(iLabels_filt, 3), 1, 1, nCls);

        %pr=[pr, evalDiffMap(Prob_filt{k}, segMap, posi_lbs)];
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% DiffusionMap using color + spatial features
    
    
    
end
save('./data/points_labels_init.mat', 'Prob_spect', 'Prob_filt');
[~,a_idx]=max(Prob_filt{k}(:,:,:), [], 3);
[~,b_idx]=max(Prob_spect{k}(:,:,:), [], 3);
figure, subplot(1,3,1), imshow(img), subplot(1,3,2),imagesc(a_idx); subplot(1,3,3); imagesc(b_idx);
