function y = vl_neigborMasking(x, neighMask, dzdy)
%neighMask(:) = 1;
neighMask = (neighMask * neighMask * neighMask * neighMask) > 0;
if nargin <= 2
  y = x .* ((neighMask + neighMask') > 0);
else
  y = dzdy .* ((neighMask + neighMask') > 0);
end