function res = res_cnn_diffMap_baseline(img, net, ns)

% substract the mean from the input image
mean_img = [122.6769, 116.67, 104.0102];
mean_img = reshape(mean_img, 1,1,3);
im = bsxfun(@minus,double(img),mean_img);

% first step: compute supper-pxiels
[labels, numlabels] = slicmex(img,500,20);
[labels, numlabels] = aggrSegms(img, labels);

% second step: construct the input data structure in gpu
data.labels = gpuArray(single(labels));
data.im = gpuArray(single(im));
data.imorig = img;

[r,c,d] = size(data.im);
idx = [4 : 8 : r-4]';
idy = [4 : 8 : c-4];
data.coor = gpuArray(single([reshape(repmat(idx, 1, length(idy)), 1, []); reshape(repmat(idy, length(idx), 1), 1, [])]));

% Perform net inference on the input data
res = vl_mysimplenn(net, data, [], []); %,  'conserveMemory', 'true');    
    
% do spectrual clustering after having the spectrals 
ly_simi = 22;
ly_eig = 24;
mat_simi = res(ly_simi).x;
mat_eig = res(ly_eig).x{1}.eig;

% return back the result
opts.dim = ns;
[res] = spectClustering(data, mat_simi, mat_eig, opts);