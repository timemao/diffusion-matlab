 load('/home/jian/Projects/DiffusionMapLearning/data/exp_bake8/net-epoch-100.mat');

net.layers(end) = [];
 init_scale0 = 1 / 1e+6;
    init_scale1 = 1e+9;
ts = gpuArray([1 : 0.1 : 1]);
numStages = 1;
for s = 1 : numStages
    if s > 1
        net.layers{end+1} = struct('type', 'featTransform', 'weights', {{eye(20), 1}}, 'ts', ts);
        net.layers{end+1} = struct('type','compSimiMatrix', 'weights', {{init_scale0}});  
    end
        
    net.layers{end+1} = struct('type','neigborMasking');
    net.layers{end+1} = struct('type', 'compNormSimiMatrix');
    net.layers{end+1} = struct('type', 'compEigDecomp');
end

if(0)
    net.layers{end+1} = struct('type', 'compDiffDist');
    net.layers{end+1} = struct('type', 'dist2SimiMatrix', 'scale', init_scale1);
else
    net.layers{end+1} = struct('type', 'featTransform', 'weights', {{eye(20), 1}}, 'ts', ts); %length(ts)
    net.layers{end+1} = struct('type','compSimiMatrix', 'weights', {{1e+1}});  
end     
net.layers{end+1} = struct('type', 'Loss');
    
