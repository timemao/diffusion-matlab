function y = vl_compNormSimiMatrix_symm(x,dzdy)

[r,d,nimg] = size(x); % each row represents feature vector of a super-pixel.
eps = 1e-5;

% This function compute the similarity matrix of super-pixels 
%if nargin <= 2
  y = gpuArray(double(zeros(r, r, nimg)));
  vones = gpuArray(double(ones(r,1)));
    for l = 1 : nimg      
     simi = squeeze(x(:, :, l));
     D = 1 ./ max(sqrt(sum(simi, 2)), eps);
     if nargin <= 1
        y(:,:,l) = diag(D) * simi * diag(D);  % D^(-1) * W         
     else      
        %y(:,:,l) = diag(D) * dzdy - vones * diag(diag(D).^2 * simi * dzdy')'; 
        %y(:,:,l) = diag(D) * dzdy - diag(diag(D).^2 * simi * dzdy') * vones'; 
        y(:,:,l) = diag(D) * dzdy * diag(D) - 0.5 * diag(D.^3) * diag(simi * diag(D) * dzdy' + (diag(D) * simi)' * dzdy) * vones';
     end
  end
%else
  % to do: compute the gradient efficiently
  
    
%end
