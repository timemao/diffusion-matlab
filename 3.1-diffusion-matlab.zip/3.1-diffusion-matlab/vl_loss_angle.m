function y = vl_loss_angle(x,gt,dzdy)


% This function computes the diffusion distance over the super-pixels 
si = size(x);
%
%d=length(x);
x=double(x(:));
no = norm(x);
gt = double(gt);
if nargin <= 2
  y = -(x(:) / no)' * gt(:) / norm(gt(:));
else
  gt = gt(:) / norm(gt(:));
  y = reshape(- 1 / no * (gt - x*(x'*gt) / no^2), si);
end
