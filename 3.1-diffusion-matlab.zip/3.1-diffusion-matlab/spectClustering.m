function [remap] = spectClustering(data, simi, mat_eig, opts)
[M,N,L] = size(simi);
t = 1;
dim = opts.dim;
for i = 1:L % if there are multiple inputs
    W = simi;
    W = (W + W') / 2;
    D = diag(sqrt(1./sum(W, 2)));

    
    %[U,S] = eig( W );
    %if isempty(mat_eig)
        [U,S] = eig(D * W * D);
    %[U, S] = eig(W);
    %else
    %    U = mat_eig.V;
    %    S = mat_eig.Gamma;
    %end
    
    % extract the top eigenvectors
    diagS = real(diag(S)); 
    [~,ind] = sort(diagS,'descend');
    U = real(U(:,ind)); 
    S = real(diag(diagS(ind)));
    
    % k-means clustering
    [res] = myfwkmeans(double(gather(U(:,1:opts.dim))),opts.dim, []);
    %[res] = myfwkmeans(double(gather(U(:, 1:dim) * diag(diag(S(1:dim,1:dim)).^(t)))),opts.dim, []);
    
end
%
%figure, subplot(1,3,1); imagesc(gather(data.imorig));

lbs = unique(data.labels);
remap = zeros(size(data.labels));
for ll = 1 : length(lbs)
remap(find(data.labels == ll)) = gather(res(ll));
end
%subplot(1,3,2),imagesc(gather(remap))

re = zeros(size(data.labels));
for ll = 1 : length(lbs)
re(find(data.labels == ll)) = gather(U(ll, 2));
end
%subplot(1,3,3),imagesc(gather(re))

%%% Compute diffusion Distance




