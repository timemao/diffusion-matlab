function [y, y1, y2] = vl_nnFeatTransform(x, l ,dzdy) 
weights = l.weights{1};
G = diag(x{1}.eig.Gamma);
V = x{1}.eig.V;
ns = size(V,1);

if(1)
    ts = l.ts; %gpuArray([0 : 0.1 : 4]);
    tmp = G.^ts;
    Bs = V * tmp; % compute diffusion map
    if nargin <= 2  
      y = Bs * weights;
      y1 = [];
      y2 = [];
    else
      %dBs =  dzdy * weights';
      Ts = gpuArray(ones(ns, 1)) * ts;
      y =  ((Bs' * dzdy));  %dzdw
      %y(:) = 0;
      y1 = (sum((V' * dzdy * weights') .* (Ts .* (G.^(ts-1))),2));  % dzdG
      y2 =  dzdy * (tmp * weights)'; % dzdV
    end
else
    if nargin <= 2  
        y = V * weights;
        y1= [];
        y2 = [];
    else
        y = V' * dzdy;
        y1 = gpuArray(zeros(size(G)));
    end
    
end