function [y]=vl_nnFeat2Dist(x, dzdy)

[r,d,nimg] = size(x); % each row represents feature vector of a super-pixel.
scale = 1e+1 * r * r;

imgx = double(squeeze(x));
xnorm = sum(imgx .^ 2, 2);

if nargin <=1
   y = (ones(r,1) * xnorm' + xnorm * ones(1, r) - 2 * imgx * imgx');     
else
   %Q = -2 * (dzdy + dzdy') .* W * scale;
   %y = cuda_compSimi_backward(double(Q), double(x));
   y = 2 * (diag(dzdy *ones(r, 1)) + diag(ones(1, r) * dzdy) - dzdy - dzdy') * imgx;
end
     