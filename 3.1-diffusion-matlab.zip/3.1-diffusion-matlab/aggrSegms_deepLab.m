function [labels, numlabels] = aggrSegms_deepLab(img, labels)

Counts = accumarray(labels(:) + 1, ones(size(labels(:))));
for d = 1 : size(img, 3)
    mean_color(:, d) = accumarray(labels(:) + 1, reshape(img(:,:,d), [], 1)) ./ Counts;
end

labels_grid = double(labels(1 : 8 : end -4 , 1 : 8 : end-4));
lbs = unique(double(labels(:)));
[b, a]=hist(labels_grid(:),lbs);
idxSet = lbs(find(b == 0));
for l = 1 : length(idxSet)
   % find neighboring segments and aggregate with the most similar segms
   map = imdilate(labels == idxSet(l), ones(3));
  try
   neigs = setdiff(unique(labels(find(map == 1))), idxSet);
   dist = sum((repmat(mean_color(idxSet(l) + 1, :), length(neigs), 1) - mean_color(neigs + 1, :)) .^ 2, 2);
   [x, id]=min(dist);
  
   labels(find(labels == idxSet(l))) = neigs(id);
   catch
       id;
   end
end
labels_bake = labels;
% relabel the segments
lbs = unique(labels(:));

for l = 1 : length(lbs)
    labels(find(labels_bake == lbs(l))) = l;
end
numlabels = length(lbs);

if (min(labels(:)) == 0)
   labels; 
end


% check again
lbs = unique(double(labels(:)));
labels_grid = double(labels(1 : 8 : end-4, 1 : 8 : end-4));
[b, a]=hist(labels_grid(:),lbs);
idxSet = lbs(find(b == 0));
if length(idxSet) > 0
   idxSet; 
end