function [y, y1]=vl_nncompSimi(x, scale, W, dzdy)

[r,d,nimg] = size(x); % each row represents feature vector of a super-pixel.
%scale = 1e-6;
% This function computes the similarity matrix of super-pixels 
%if nargin <= 3
% y = gpuArray(double(zeros(r, r, nimg)));  
%  y1 = gpuArray(double(zeros(1, 1, nimg)));  
%  for l = 1 : nimg      
     imgx = double(squeeze(x));
     xnorm = sum(imgx .^ 2, 2);
     D = (ones(r,1) * xnorm' + xnorm * ones(1, r) - 2 * imgx * imgx');
     %y(:,:,l) = exp(-1/d * (ones(r,1) * xnorm' + xnorm *  ones(1, r) - 2 * imgx * imgx'));  % L2 distance    
     if nargin <=3
         y = double(exp(-scale * D));  % L2 distance          
         y1 = [];
     else
         Q = -2 * (dzdy + dzdy') .* W * scale;
         y = cuda_compSimi_backward(double(Q), double(x));
         y1 = sign(sum(sum(dzdy .* (-D) .* exp(-scale * D)))); 
         if abs(y1) / scale < 1e-2
            y1 = y1 * scale / abs(y1) * 1e+2;
         end
         if abs(y1) / scale > 1
            y1 = y1 * scale / abs(y1) *1e+2;
         end
         
         y1 = 0;
     end
     
     %y(:,:,l) = double(imgx * imgx');
%  end
%else
  % to do: compute the gradient efficiently
  
  
  % using GPU implementation
   % to be updated
  
  %y= double((dzdy' + dzdy) * x);
end