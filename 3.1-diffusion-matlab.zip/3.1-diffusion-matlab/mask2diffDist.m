function [diffDist, Prob] = mask2diffDist(mask, segs)
lbs = unique(mask);  
% numSegs = length(unique(segs));
Counts = accumarray(segs(:), ones(size(mask(:))));
% SumVal = accumarray(segs(:) + 1, mask(:));  
% Prob = ((SumVal ./ Counts));
% diff = Prob * ones(1, numSegs) - ones(numSegs, 1) * Prob';
% diffDist = abs(diff);
% diffDist(diffDist > 0.5) = 1;

if(1)
    for l = 1 : length(lbs)
        pcmask = (double(mask) == l);
        SumVal = accumarray(segs(:), double(pcmask(:)));  
        Prob(:,l) = round(SumVal ./ Counts);
    end
end

diffDist = 1-Prob * Prob';

if(0)
   map = zeros(size(mask));
   for l = 1 : length(unique(segs(:)))
      map(find(segs == l))= diffDist(318, l);       
   end
   figure,imshow(map,[])
end
