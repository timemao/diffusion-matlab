function y = vl_loss(x,gt,dzdy)


% This function computes the diffusion distance over the super-pixels 
x=double(x);
gt = double(gt);
if nargin <= 2
  %y = gpuArray(single(zeros(r, r, nimg)));  
  y = sum((x(:) - (1-gt(:))) .^ 2);
else
  y = 2 * dzdy * (x - (1-gt));    
end
