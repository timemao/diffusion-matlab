function [y, data] = vl_nnSpixelAggr_max(x, data, dzdy)

% This function aggragate features in each super-pixel, using average
% pooling
[r,c] = size(data.labels);
coor_idx = sub2ind([r,c], data.coor(1, :), data.coor(2, :))';

if nargin <= 2
  data.nPsPerSeg = accumarray(data.labels(coor_idx), ones(1, length(coor_idx)));
  data.nSegs = length(data.nPsPerSeg);
  [y, data.maxposi] = cuda_SpixelAggr_max_foward(x, data.labels(coor_idx), data.nSegs, coor_idx); % x: (N_pixels * D_feature); coor_idx: (N_pixels * 1); 
else
  y = cuda_SpixelAggr_max_backward(x, data.labels(coor_idx), single(data.nPsPerSeg),data.maxposi, single(dzdy)); % to be done
  y = reshape(y, size(x));
end
