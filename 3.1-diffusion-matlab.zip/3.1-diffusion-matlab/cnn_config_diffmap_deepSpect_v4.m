% this is the config file shared by the different trainers
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% supported configuration list
% 1 - segmentation

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% layers in alexnet
% 14 - relu5
% 13 - conv5
% 12 - relu4
% 11 - conv4
% 10 - relu3
%  9 - conv3
%  8 - pool2
%  6 - relu2
%  5 - conv2

mean_img = [122.6769 116.6700 104.0102];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  % ncuts
%addpath(genpath('../../seism'))

variant = opts.train.conf;
target_layer_id = opts.train.target_layer_id;
opts.lite = false;
switch variant
  case 'j2_alexnet_fc_toponly'
    model_name = ['alexnet_' opts.imgset_train '_layer_id_' num2str(target_layer_id) '_ncuts_j2_fc_toponly'];
    net = load(['pretrained/imagenet-caffe-alex.mat']);
    %model_name = ['alexnet_' opts.imgset_train '_val11_2x_stride_250'];
    %net = load(['../imagenet-caffe-alex-stride2.mat']);

    opts.train.batchSize = 1; % 30
    opts.train.conserveMemory = false;

    TARGET_OBJ_SIDE = 200; % 227 is side of image, dividing by 2x stride and subtracting a little bit for border 
    net.layers = net.layers(1:target_layer_id);

    init_bias = 0;
    switch target_layer_id
      case 14
        init_var = .01;
        
        if opts.subset == 500
          error('not setup');
        else
          Ldims = [256 20];
%           Ldims = [2048 20]; 
%           Ldims = [4096 20]; 
%           Ldims = [4096 40]; 
          % basemult = 1, dropout rate is 0

          basemult = 1;
%           opts.train.learningRate = .0001/basemult*[ones(1,5)]; 
          opts.train.learningRate = .0001/basemult*[ones(1,7)]; 
        end
        
        net.layers{end+1} = struct('type', 'conv', ...
                                  'filters', init_var*randn(3,3,256,Ldims(1), 'single'),...
                                  'biases', init_bias*ones(1,Ldims(1),'single'), ...
                                  'filtersLearningRate', 10*basemult, ...
                                  'biasesLearningRate', 10*basemult, ...
                                  'stride', 1, ...
                                  'pad', [1 1 1 1], ...
                                  'filtersWeightDecay', 1, ...
                                  'biasesWeightDecay', 0);
        net.layers{end+1} = struct('type', 'relu') ;
        net.layers{end+1} = struct('type','dropout','rate',.25);
        net.layers{end+1} = struct('type', 'conv', ...
                                  'filters', init_var*randn(1,1,Ldims(1),Ldims(2), 'single'),...
                                  'biases', init_bias*ones(1,Ldims(2),'single'), ...
                                  'filtersLearningRate', 10*basemult, ...
                                  'biasesLearningRate', 10*basemult, ...
                                  'stride', 1, ...
                                  'pad', 0, ...
                                  'filtersWeightDecay', 1, ...
                                  'biasesWeightDecay', 0);
        net.layers{end+1} = struct('type', 'relu') ;
      otherwise
        error('');
    end    
    net.layers{end+1} = struct('type','custom','forward',@nnsimilarity_forward,...
                                'backward',@nnsimilarity_backward,'eigspace','geig','dims',2:1:14,'weight',[1],...
                                'kernels',{{{'lin_f'}}},...
                                'kernel_params',{{{eye(Ldims)}}},'postproc','scc');
                              warning('lin_f');
    net.layers{end+1} = struct('type','custom_segmentation','forward',@nnsegmentation_loss_forward,'backward',@nnsegmentation_loss_backward,'method','bach_j2');

    Ldims
%    opts.train.momentum = 0; % orig
%    opts.train.weightDecay = 0; % ORIG
     opts.train.momentum = .9;
     opts.train.weightDecay = .005;
     
  case 'j2_vgg_fc_toponly'
    model_name = ['vgg_' opts.imgset_train '_layer_id_' num2str(target_layer_id) '_ncuts_j2_fc_toponly'];
    net = load(['pretrained/imagenet-vgg-verydeep-16.mat']);

    opts.train.batchSize = 1; % 30
    opts.train.conserveMemory = false;

    net.layers = net.layers(1:target_layer_id);
%     for i = 1: length(net.layers)
%       if strcmp(net.layers{i}.type,'conv')
%         net.layers{i}.filtersLearningRate = 0;
%         net.layers{i}.biasesLearningRate = 0;
%       end
%     end
    ts = gpuArray([1 : 0.1 : 1]);
    switch target_layer_id
      case {26,30}
        init_var = .01;
        init_bias = 0;    
        if target_layer_id == 26 || target_layer_id == 30
          if opts.subset == 500
            Ldims = [1024 128];
            basemult = 1;
            opts.train.learningRate = .0001/basemult*[.5*ones(1,3) .1*ones(1,3) .05*ones(1,3)]; % ORIG
            dropout_rate = .25;
          else
            Ldims = [1024 128];             
            basemult = 10;
            % opts.train.learningRate = .001/basemult*[.5*ones(1,3) .1*ones(1,3) .05*ones(1,3)]; % tried .5*ones(1,3) .1*ones(1,3) .05*ones(1,3) seems good
            % logspace(log10(.5),log10(.05),7) % ok but not better
            opts.train.learningRate = .001/basemult*logspace(log10(.75),log10(.05),50)%[.75*ones(1,2) .5*ones(1,2) .25*ones(1,2) .1*ones(1,2) .07*ones(1,2) .05*ones(1,3)]; % tried .5*ones(1,3) .1*ones(1,3) .05*ones(1,3) seems good
            dropout_rate = .5;%.25
          end
        end
      
        net.layers{24}.stride = [1, 1];
        net.layers{24}.pad = [0, 1, 0, 1];
        % this should be 0.02
        % or .014
        %net.layers{end+1} = struct('type','dropout','rate',dropout_rate);
        net.layers{end+1} = struct('type', 'conv', ...
                                  'filters', init_var*randn(3,3,512,Ldims(1), 'single'),...
                                  'biases', init_bias*ones(1,Ldims(1),'single'), ...
                                  'filtersLearningRate', basemult, ...
                                  'biasesLearningRate', 2*basemult, ...
                                  'stride', 1, ...
                                  'pad', [1 1 1 1], ...
                                  'filtersWeightDecay', 1, ...
                                  'biasesWeightDecay', 0);
        net.layers{end+1} = struct('type', 'relu') ;
        %net.layers{end+1} = struct('type','dropout','rate',dropout_rate);
        % this should be 0.04
        % or .3
        net.layers{end+1} = struct('type', 'conv', ...
                                  'filters', init_var*randn(1,1,Ldims(1),Ldims(2), 'single'),...
                                  'biases', init_bias*ones(1,Ldims(2),'single'), ...
                                  'filtersLearningRate', basemult, ...
                                  'biasesLearningRate', 2*basemult, ...
                                  'stride', 1, ...
                                  'pad', 0, ...
                                  'filtersWeightDecay', 1, ...
                                  'biasesWeightDecay', 0);
        net.layers{end+1} = struct('type', 'relu') ;
      case 19
        init_var = .01;
        init_bias = 0; 

        Ldims = [1024 20]; %128
        basemult = 10;
        opts.train.learningRate = .01/basemult*logspace(log10(.5),log10(.05),10);%[.5*ones(1,3) .1*ones(1,3) .05*ones(1,3)]; % ORIG
        dropout_rate = .25;
        net.layers{end+1} = struct('type', 'conv', ...
                                  'filters', init_var*randn(3,3,512,Ldims(1), 'single'),...
                                  'biases', init_bias*ones(1,Ldims(1),'single'), ...
                                  'filtersLearningRate', basemult, ...
                                  'biasesLearningRate', 2*basemult, ...
                                  'stride', 1, ...
                                  'pad', [1 1 1 1], ...
                                  'filtersWeightDecay', 1, ...
                                  'biasesWeightDecay', 0);
        net.layers{end+1} = struct('type', 'relu') ;
        net.layers{end+1} = struct('type','dropout','rate',dropout_rate);
        net.layers{end+1} = struct('type', 'conv', ...
                                  'filters', init_var*randn(1,1,Ldims(1),Ldims(2), 'single'),...
                                  'biases', init_bias*ones(1,Ldims(2),'single'), ...
                                  'filtersLearningRate', basemult, ...
                                  'biasesLearningRate', 2*basemult, ...
                                  'stride', 1, ...
                                  'pad', 0, ...
                                  'filtersWeightDecay', 1, ...
                                  'biasesWeightDecay', 0);
        net.layers{end+1} = struct('type', 'relu') ;
      otherwise
        error('');
    end    
    
    init_scale0 = 1; %log(1e-6); %1e+0; %1e+3;%
    init_scale1 = 1; %log(1e+3); %5e+0; %
    net.layers{end+1} = struct('type','SpixelsAggr_avr');  
    %net.layers{end+1} = struct('type','compSimiMatrix', 'weights', {{init_scale0}});  
    net.layers{end+1} = struct('type','Feat2Dist');  
   
    net.layers{end+1} = struct('type','dist2SimiMatrix_scale', 'weights', {{init_scale0}}); % _scale_scale 
    net.layers{end+1} = struct('type','neighMasking_v2');
    
    net.layers{end+1} = struct('type', 'compNormSimiMatrix');
    net.layers{end+1} = struct('type', 'compEigDecomp');
    
    numStages = 0;
    for s = 1 : numStages
        net.layers{end+1} = struct('type', 'featTransform', 'weights', {{eye(20), 1}}, 'ts', ts);
        net.layers{end+1} = struct('type','compSimiMatrix', 'weights', {{init_scale0}});  
        %net.layers{end+1} = struct('type', 'compDiffDist');
        %net.layers{end+1} = struct('type', 'dist2SimiMatrix', 'scale', init_scale1);
        net.layers{end+1} = struct('type','neigborMasking_v2');
        net.layers{end+1} = struct('type', 'compNormSimiMatrix');
        net.layers{end+1} = struct('type', 'compEigDecomp');
    end
    
    powerscale = 6;
    if(1)
        net.layers{end+1} = struct('type', 'compDiffDist', 'weights', {{powerscale}});
        net.layers{end+1} = struct('type', 'dist2SimiMatrix_scale', 'weights', {{init_scale1}}); %_scale_scale
    else
        net.layers{end+1} = struct('type', 'featTransform', 'weights', {{eye(100), 2}}, 'ts', ts); %length(ts)
        net.layers{end+1} = struct('type','compSimiMatrix', 'weights', {{init_scale1 }}); %1e+3 
    end     
    net.layers{end+1} = struct('type', 'Loss');
    
%   net.layers{end+1} = struct('type','custom_segmentation','forward',@nnsegmentation_loss_forward,'backward',@nnsegmentation_loss_backward,'method','bach_j2');
%   opts.train.momentum = 0;
%   opts.train.weightDecay = 0;

    opts.train.momentum = .9;
    opts.train.weightDecay = .005;
   
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  case 'none_vgg'
    model_name = ['vgg_' opts.imgset_train '_layer_id_' num2str(target_layer_id) '_ncuts_none'];
    net = load(['pretrained/imagenet-vgg-verydeep-16.mat']);

    opts.train.batchSize = 1; % 30
    opts.train.conserveMemory = false;

    TARGET_OBJ_SIDE = 200; % 227 is side of image, dividing by 2x stride and subtracting a little bit for border 
    net.layers = net.layers(1:target_layer_id);

    net.layers{end+1} = struct('type','custom','forward',@nnsimilarity_forward,...
                                 'backward',@nnsimilarity_backward,'weight',[1],...
                                'kernels',{{{'lin_f'}}},...
                                'kernel_params',{{{1e-2*eye(512)}}},'postproc','scc');
    net.layers{end+1} = struct('type','custom_segmentation','forward',@nnsegmentation_loss_forward,'backward',@nnsegmentation_loss_backward,'method','none');
    opts.train.learningRate = 0.01*[ones(1, 1)];
    
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
  case 'none_alexnet'
    model_name = ['alexnet_' opts.imgset_train '_layer_id_' num2str(target_layer_id) '_ncuts_none'];
    net = load(['pretrained/imagenet-caffe-alex.mat']);

    opts.train.batchSize = 1; % 30
    opts.train.conserveMemory = false;

    TARGET_OBJ_SIDE = 200; % 227 is side of image, dividing by 2x stride and subtracting a little bit for border 
    net.layers = net.layers(1:target_layer_id);

    net.layers{end+1} = struct('type','custom','forward',@nnsimilarity_forward,...
                                'backward',@nnsimilarity_backward,'weight',[1],...
                                'kernels',{{{'lin_f'}}},...
                                'kernel_params',{{{eye(256)}}},'postproc','scc');
    net.layers{end+1} = struct('type','custom_segmentation','forward',@nnsegmentation_loss_forward,'backward',@nnsegmentation_loss_backward,'method','none','dims',2:6,'k',10);
    opts.train.learningRate = 0.01*[ones(1, 1)];  
  
  otherwise
    error('no variant given!');
end
opts.train.errorType = 'sc';
if opts.lite
  model_name = [model_name '_lite'];
end
name = 'alexnet_orig';
opts.loss = 'none'


opts.train.learningRate
