function [y, ys] = vl_loss_mixed_spectCluster(x,sm,gt,dzdy)
[r,c,d] = size(x);

% This function computes the diffusion distance over the super-pixels 
E = double(gt);
W = double(x);
W = symmetric(W);
%D = ((diag(sqrt(1 ./ sum(W, 2)))));
%[UW, GW]=eig(symmetric(D * W * D));
[UW, GW]=eig((W));

NE = E * E';
NE = max(NE, eye(size(NE)));
DE = diag(sqrt(1 ./ sum(NE, 2)));
T = (DE * NE * DE);

%NE = T;
tau = 1e-2; %0.1;
no = norm(sm(:));
%sm = min(max(sm,1e-10), 1-1e-10);
if nargin <= 3
   % foward: compute loss
   y = 0.04* norm(UW * thresh(real(GW), tau) * UW' - T, 'fro')^2 + ...
       - 0 * (sm(:) / no)' * NE(:) / norm(NE(:));  %0.5 * norm(sm - NE, 'fro')^2 / prod(size(sm));
   
   %y = -(x(:) / no)' * NE(:) / norm(NE(:)); 
   %y = 0.1 * norm(UW * thresh(real(GW), tau) * UW' - T, 'fro')^2 + ...
   %    -(log(sm(:))' * NE(:) + log(1 - sm(:))' * (1 - NE(:))) / prod(size(sm));  %0.5 * norm(sm - NE, 'fro')^2 / prod(size(sm));
   
   %if(y > 1e+2)
   %    y;
   %end
else
   % backward: compute gradient
   
   if(1)
   % compute k
   vone = gpuArray(double(ones(r,1)));
   diff = real(diag(GW))*vone'-real(diag(GW)*vone')';
   K = 1 ./ diff;
   K(eye(size(K,1))>0)=0;
   K((isnan(K))) = 0;
   K((isinf(K))) = 0;
   %K(abs(K) > 1e+10) = 0;
   
   % compute gradient
   GWth = thresh(real(GW), tau);
   P = UW * GWth * UW';
   y = 0.08*UW * (K' .* ((UW' * (P - T) * UW * GWth - GWth * UW' * (P - T) * UW)) + ...
      diagEig(thresh_grad(GW, GWth, tau) * (UW' * (P - T) * UW))) * UW'; % + (W - T);  % 2* 0.1 * (P-T);
   
   
   %% inner product loss
   gt = NE(:) / norm(NE(:));
   sm = sm(:);
   ys = 0 * reshape(- 1 / no * (gt - sm*(sm'*gt) / no^2), size(x));
   
   else
       gt = NE(:) / norm(NE(:));
       x = x(:);
       y = reshape(- 1 / no * (gt - x*(x'*gt) / no^2), size(W));
       %ys = 0;
   end
   
   
   %% cross-entropy losstrain
   %ys = (- NE ./sm + (1 - NE) ./ (1 - sm)) / prod(size(sm));
   %y %s = ;%(sm-NE)  / prod(size(sm));
   %y = UW * (2 * K' .* (UW' * Gwth * UW * (P - T)) + ...
   %   diagEig(thresh_grad(GW, GWth, tau) * UW' * (P - T) * UW)) * UW'; 
  
end




function y = symmetric(W)
y = (W + W') / 2;

function y = diagEig(x)
y = diag(diag(x));

function y = thresh(E, tau)
%y 
if(0)
eps = 1e-5;
Ediag = max(diag(E), eps);
y = diag((1 ./ (1 + exp(-10 * (log(Ediag) - log(tau))))));
else
    y = diag(double(diag(E) > tau) .* diag(E));
    %y = diag(double(diag(E) > tau));
    %y = diag(1 ./ (1 +  exp(-10 * (diag(E) - tau))));
end

function dy = thresh_grad(E, y, tau)
if(0)
eps = 1e-5;
Ediag = max(diag(E), eps);
dy = diag((10  ./ Ediag) .* diag(y) .* (1 - diag(y)));
dy(dy < eps) = 0;
else
    dy = diag(double((diag(E) > tau)));
    %dy = 2 * E;
    %dy =  diag(10 .* diag(y) .* (1 - diag(y)));
end

