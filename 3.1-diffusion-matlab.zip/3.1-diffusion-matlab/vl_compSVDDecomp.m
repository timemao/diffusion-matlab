function y = vl_compSVDDecomp(x,eigs, dzdV, dzdG)

[r,d,nimg] = size(x); % each row represents normalized similarity of a pixel with the remaining pixels.

% This function compute the similarity matrix of super-pixels 
if nargin <= 1
  %y = gpuArray(single(zeros(r, r, nimg)));
  for l = 1 : nimg      
     nsimi = squeeze(x(:, :, l));
     [U, G, V] = svd(double(nsimi));
     eig.U = U;
     eig.Gamma = G;
     eig.V = V;
     y{l}.eig = eig;
  end
else
  % to do: compute the gradient efficiently
  n_neig = size(dzdV, 2);
  vone = gpuArray(double(ones(r,1)));
  dzdV = [dzdV, gpuArray(double(zeros(r, r-n_neig)))];
  dzdG = [dzdG, gpuArray(double(zeros(1, r-n_neig)))];  
  U = eigs{1}.eig.U;
  V = eigs{1}.eig.V;
  G = eigs{1}.eig.Gamma;
  %K = 1 ./ ((diag(G) * vone').^2 - (vone * diag(G)').^2);  
  %K = K - diag(diag(K));
  diff = diag(G).^2*vone'-(diag(G).^2*vone')';
  %K = 1./max(diff, 1e-8); 
  K = 1 ./ diff;
  K(eye(size(K,1))>0)=0;
  K((isnan(K))) = 0;
  K((isinf(K))) = 0;
  y = U * diag(dzdG') * V' + 2 * U * G * symm(K' .* (V' * dzdV)) * V';
end


function B = symm(A)
B = 1/2 * (A + A');
