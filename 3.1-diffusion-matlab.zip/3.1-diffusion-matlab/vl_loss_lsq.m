function y = vl_loss_lsq(x,gt,dzdy)


% This function computes the diffusion distance over the super-pixels 
x=double(x);
gt = double(gt);
if nargin <= 2
  %y = gpuArray(single(zeros(r, r, nimg)));  
  y = mean((x(:) - (gt(:))) .^ 2);
else
  y = 2 * dzdy * (x - (gt)) * 1e-5;    
end
