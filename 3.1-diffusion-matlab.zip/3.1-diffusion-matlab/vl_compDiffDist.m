function [y, z, dzdt] = vl_compDiffDist(x,scale,dzdy)

[r,d,nimg] = size(x{1}.eig.V); % each row represents normalized similarity of a pixel with the remaining pixels.
n_eigs = 100; %d; %l.neigs;
%t = ones(r, 1) * 2; %l.t;
%t(1) = 0;
t = scale; %1; %l.scale; %0.25;
st = 1;
l = 1;
x{l}.eig.Gamma = max(x{l}.eig.Gamma, 0);
% This function computes the diffusion distance over the super-pixels 
if nargin <= 2
  %y = gpuArray(single(zeros(r, r, nimg)));
  E = gpuArray(single(ones(r,n_eigs-st + 1)));
  for l = 1 : nimg      
     Phi = x{l}.eig.V(:, st : n_eigs);
     Phi2 = Phi.^2;
     eVs = diag(diag(x{l}.eig.Gamma(st:n_eigs, st : n_eigs)) .^ (2*t));
     y = E * eVs * Phi2' + Phi2 * eVs * E' - 2 * Phi * eVs * Phi';     
  end
  z = [];
else
  % to do: compute the gradient efficiently
  vone = gpuArray(double(ones(r, 1)));
  dzdt = 0;
  for l = 1 : nimg 
     Phi = x{l}.eig.V(:, st : n_eigs);
     Gs = x{l}.eig.Gamma;
     y = 2 * (diag(dzdy' * vone) * Phi + diag(dzdy * vone) * Phi - dzdy' * Phi - dzdy * Phi) * ((x{l}.eig.Gamma(st:n_eigs, st: n_eigs)) .^ (2*t));
     % the followling codes can be implemented by GPU device
     Ks = gpuArray(single(zeros(r * r, n_eigs-st + 1)));
     %dt = gpuArray(single(zeros(r * r, n_eigs-st + 1)));
     for p = 1 : n_eigs - st + 1
        tmp = vone * (Phi(:, p).^2)' +  Phi(:, p).^2 * vone' - 2 * Phi(:,p) * Phi(:,p)';
        Ks(:, p) = reshape(2 * t  *  Gs(p, p) ^(2*t - 1) * tmp , [], 1);
        dzdt = dzdt + 2 * log(max(Gs(p, p), 1e-10))  *  Gs(p, p) ^(2*t) * tmp;
     end
     z = dzdy(:)' * Ks; 
     dzdt = dzdy(:)' * dzdt(:);
  end 
  z = z';
 
    
end

