% this function try to match two images
