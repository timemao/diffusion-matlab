function y = vl_loss_wkSup(x,wkLabel,dzdy)


% This function computes the diffusion distance over the super-pixels 
y=gpuArray(zeros(size(x)));
si = size(x);
gt= wkLabel.labs;
x=x(wkLabel.supp, wkLabel.supp);
labshot = ind2vec(gt');
labshot = full([labshot', zeros(length(gt), 21-size(labshot, 1)) ]);
W = labshot * labshot';
gt = W;
%
%d=length(x);
x=double(x(:));
no = norm(x);
if nargin <= 2
  y = -(x(:) / no)' * gt(:) / norm(gt(:));
else
  gt = gt(:) / norm(gt(:));
  y(wkLabel.supp, wkLabel.supp) = reshape(- 1 / no * (gt - x*(x'*gt) / no^2), size(W));
  
end
