function Segmentation = RemoveIsoSegs(Segmentation, im, threshold)
Segmentation0 = Segmentation;
labs = unique(Segmentation(:));
se = strel('sphere',13);
im = reshape(im, [], size(im,3));
for l = 1 : length(labs)
    idSet = find(Segmentation == l);
    if (length(idSet) < threshold)
        map = (Segmentation == l);
        map2 = imdilate(map, se);
        mask = (map2 == 1) &( map == 0);
        avr_ref = mean(im(find(map), :), 1);
        lbset = unique(Segmentation(find(mask)));
        diff = [];
        for p = 1 : length(lbset)
            clb = lbset(p);
            avr(:, p) = mean(im(find(mask & (Segmentation == clb)), :), 1);
            diff(p) = mean(abs(avr_ref' - avr(:, p)));
        end
        [~, lb_merg] = min(diff);
        try
        lb_merg = lbset(lb_merg);
        catch
            lb_merg
        end
        Segmentation0(find(map)) = lb_merg;
    end
end

% re-arange the labels
lbAll = unique(Segmentation0(:));
for p = 1 : length(lbAll)
    Segmentation0(find(Segmentation0 == lbAll(p))) = p;
end

Segmentation = Segmentation0;

