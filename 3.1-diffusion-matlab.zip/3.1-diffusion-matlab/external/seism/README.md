![seism](seism.png)

Code package that implements the image segmentation measures and reproduces all results from the CVPR2013 paper:

**Measures and Meta-Measures for the Supervised Evaluation of Image Segmentation**<br/>
Jordi Pont-Tuset and Ferran Marques, CVPR 2013.

More info at the [project page](https://imatge.upc.edu/web/resources/supervised-evaluation-image-segmentation). 