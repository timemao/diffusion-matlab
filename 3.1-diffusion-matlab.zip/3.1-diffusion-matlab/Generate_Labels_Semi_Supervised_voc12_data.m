%clear all;
close all %clc;
load('classes.mat');
load('cmap.mat');
clsIdx = 1:numel(classes);
clsMap = containers.Map(classes, clsIdx);

load('/home/jian/download_projects/matconvnet-fcn-master/data/fcn8s-voc12_diffMap/imdb.mat');

file = fopen('VOC2012_imgList.txt', 'a');
idset = find(images.set == 2 | images.set == 1);
nimgs = length(idset);
confusion = zeros(21,21);
figure,
for id = 1: 1 : nimgs
    %k = 4788
    try
    k = idset(id)
    name = images.name{k};
    imname = sprintf(paths.image, name);
    
    if(0)
        gtname = sprintf(paths.classSegmentation, name);    
        anno = imread(gtname) ;
        lbmap = single(anno) ;
        lbmap = mod(lbmap + 1, 256) ; % 0 = ignore, 1 = bkg  
    end
    
    if(0)
        % read in the image and the scribble annotation
        im = imread(imname); %'2008_003147.jpg');
        
        spots = readspots([name,'.xml'], clsMap); %2008_003147
        indx = sub2ind([size(im, 1), size(im, 2)], spots(:,2), spots(:,1));
        cls = spots(:, 3);
        lamap = zeros(size(im, 1), size(im, 2));
        clset = unique(cls);
        for c = 1 : length(clset)
           lamap(indx(find(cls == clset(c)))) = clset(c);
        end
        se = ones(1,1);
        lamap = imdilate(lamap, se);
        %subplot(1,3,1);imshow(uint8(im))

        load(images.diffname{k});
        sps = data.labels(find(lamap > 0));
        labs_segs = zeros(size(data.simi, 1), 1);
        labs_segs(sps) = lamap(find(lamap > 0));
        labs = find(lamap > 0);
        %subplot(1,3,2), imagesc(reshape(labs_segs(data.labels), size(data.labels)))
        %axis image;
        
        %im = gather(data.im);
        im = double(imread(imname));
        neighMask = gather(data.neighMask);
        labels = gather(data.labels);
        coor = gather(data.coor);
    
        save(['./data/VOC2012_Train_scribbleLabels/', name, '.mat'], 'im', 'neighMask', 'labels', 'coor', 'lamap');
    end
    
        %fwrite(file, name);
        %fprintf(file, '\n');
        im = double(imread(imname));
        save(['./data/VOC2012_Train_scribbleLabels/', name, '.mat'], 'im', '-append');
    
    end
end
    