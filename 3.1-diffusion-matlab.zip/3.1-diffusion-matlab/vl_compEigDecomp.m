function y = vl_compEigDecomp(x,eigs, dzdV, dzdG)

[r,d,nimg] = size(x); % each row represents normalized similarity of a pixel with the remaining pixels.

% This function compute the similarity matrix of super-pixels 
if nargin <= 1
  %y = gpuArray(single(zeros(r, r, nimg)));
  for l = 1 : nimg      
     
     nsimi = squeeze(x(:, :, l));
      
%      save tmp.mat nsimi;
%      fprintf(' ! ')
      
      [V, G] = eig(double(gather(nsimi)));
      
%      fprintf(' ! ')
      
     val = real(diag(G));
     [~, ind] = sort(real(val), 'descend');
     %eig.U = U;
     eigs.Gamma = gpuArray(real(diag(val(ind))));
     eigs.V = gpuArray(real(V(:, ind)));
     y{l}.eig = eigs;
  end
else
  % to do: compute the gradient efficiently
  n_neig = size(dzdV, 2);
  vone = gpuArray(double(ones(r,1)));
  dzdV = [dzdV, gpuArray(double(zeros(r, r-n_neig)))];
  dzdG = [dzdG', gpuArray(double(zeros(1, r-n_neig)))]';  
 %U = eigs{1}.eig.U;
  V = eigs{1}.eig.V;
  G = eigs{1}.eig.Gamma;
  %K = 1 ./ ((diag(G) * vone').^2 - (vone * diag(G)').^2);  
  %K = K - diag(diag(K));
  %diff = diag(G).^2*vone'-(diag(G).^2*vone')';
  
  diff = diag(G)*vone'-(diag(G)*vone')';
  %diff 
  
%%%%%%%%% should like this: diff = diag(G)*vone'-(diag(G)*vone')';
  
  %K = sign(diff) * (1./max(abs(diff), 1e-8)); 
  K = 1 ./ diff;
  K(eye(size(K,1))>0)=0;
  K((isnan(K))) = 0;
  K((isinf(K))) = 0;
  %K(K>1e+15) = 0;
  %K(K<-1e+15) = 0;

  %y = U * diag(dzdG') * V' + 2 * U * G * symm(K' .* (V' * dzdV)) * V';
  y = V * diag(dzdG') * V' + V * (K' .* (V' * dzdV)) * V';
end


function B = symm(A)
B = 1/2 * (A + A');
