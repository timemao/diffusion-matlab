%% This function learn for semantic segmentation with the weak point-wise supervision
close all

nCls = 21;
addpath('/home/jian/download_projects/matconvnet-fcn-master/')
addpath('/home/jian/download_projects/whats-the-point1-master/whats_the_point/whats_the_point/data/');
addpath(genpath('./'))
run('/home/jian/download_projects/matconvnet-1.0-beta24/matlab/vl_setupnn.m');
addpath(genpath('/home/jian/download_projects/matconvnet-1.0-beta24/examples'));
addpath('/home/jian/download_projects/vlfeat-master/toolbox');

%% Step 1: generate the initial labels given the weak point-wise supervisions
%load('/home/jian/Projects/DiffusionMapLearning/data/exp_bake8/net-epoch-100.mat');
load('/home/jian/Projects/DiffusionMapLearning/data/exp/net-epoch-95.mat');
if(0)
    net.layers(end) = [];
    net.layers{41}.weights{2} = 10
    net.layers{end}.weights{1} = 1e+4;

    net.layers(end) = [];
    net.layers{end+1} = struct('type', 'neighMasking_v2');
    net.layers{end+1} = struct('type', 'compNormSimiMatrix');
    net.layers{end+1} = struct('type', 'compEigDecomp');
    net.layers{end+1} = struct('type', 'compDiffDist');
    net = vl_simplenn_move(net, 'gpu');
end

net0 = net;
net0 = vl_simplenn_move(net0, 'gpu');

%%%%%%%%%%%%
%load point labels
load('./data/points_labels.mat', 'Points_trainval', 'Points_supp', 'IDs_supp', 'IDs_trainval');
folderpath = '/media/jian/oldsystem/home/jian/Database/VOC/VOC2012/VOCdevkit/VOC2012/JPEGImages/';
foldersegm_gt = '/media/jian/oldsystem/home/jian/Database/VOC/VOC2012/VOCdevkit/VOC2012/SegmentationClass/';
savefolder = '/home/jian/Projects/DiffusionMapLearning/data/VOC_point/';

%net0.layers(33) = [];
list_file = dir(foldersegm_gt);
pr = [];
for k = 11176: length(IDs_trainval)
    k
%for k = 40 : length(list_file)
    imid = k; %find(strcmp(IDs_trainval, list_file(k).name(1 : end-4)));
    imgpath = [folderpath, IDs_trainval{imid}, '.jpg'];
    posi_lbs = [];
    for tt = 1 : length(Points_trainval{imid})
        posi_lbs = [posi_lbs; [Points_trainval{imid}{tt}.y, Points_trainval{imid}{tt}.x, Points_trainval{imid}{tt}.cls]];
    end
    %%%%%%%%%%%%
    %% load ground-truth segmentation labels
    if(0)
        igt_seg = [foldersegm_gt, IDs_trainval{imid}, '.png'];
        try
          [segMap,map] = imread(igt_seg);
        catch
           segMap = [];
        end

        if ~isempty(segMap)
             segMap;
        end
    end
    %imgpath = '/media/jian/oldsystem/home/jian/Database/Saliency/BenchmarkIMAGES/BenchmarkIMAGES/i40.jpg';
    %imgpath = '/media/jian/oldsystem/home/jian/Database/BSR/BSDS500/data/images/train_all/112082.jpg';
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% Ours
    if ~isempty(posi_lbs)
        sfile = [savefolder, IDs_trainval{imid}, '.mat'];
        load(sfile, 'data');
        diff = data.diffDist;
        
        lbs = unique(posi_lbs(:, 3)) + 1;
        img = imread(imgpath); %2007_000175
        [iLabels_filt, data_info] = GenerateInitalLabels_Diff(imgpath, net0, posi_lbs, data.labels);
        
        data = data_info.data;        
        data.diffDist_v2{1} = iLabels_filt(:, [1, lbs']);
        data.diffDist = diff;
        data.simi = data_info.simi;
        data.pts = posi_lbs;
       
        save(sfile, 'data');
    end   
end