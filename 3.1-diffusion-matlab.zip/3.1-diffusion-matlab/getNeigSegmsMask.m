%% This function is to generate a neigboring mask indicating the neighboring relationship
%% between segments
function [neig_mask] = getNeigSegmsMask(labels)

if min(labels(:)) == 0
    labels = labels + 1;
end

[r,c] = size(labels);
nsegs = size(unique(labels), 1);
neig_mask = diag(ones(1, nsegs));


neigSet = [reshape(labels, 1, []); reshape(labels([2 : end, end], :), 1, [])];
idSet = find(neigSet(1, :) ~= neigSet(2, :));
idTmp = unique(neigSet(:, idSet)', 'rows')';
try
    neig_mask(sub2ind([nsegs,nsegs], idTmp(1,:), idTmp(2,:))) = 1;
catch
    1;
end

neigSet = [reshape(labels, 1, []); reshape(labels(:, [2 : end, end]), 1, [])];
idSet = find(neigSet(1, :) ~= neigSet(2, :));
idTmp = unique(neigSet(:, idSet)', 'rows')';
neig_mask(sub2ind([nsegs,nsegs], idTmp(1,:), idTmp(2,:))) = 1;
