function [segs, eigs, Gs] = cnn_diffMap_deepSpect_v3(imdb,varargin)
% Main function to lear the diffusion map
% cnn_segm_bsds_new('conf','j2_vgg','target_layer_id',26,'subset',300,'testonly',true)
% .69| .576
% cnn_segm_bsds_new('conf','j2_vgg','target_layer_id',26,'subset',500,'testonly',true)
% .65| .56

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Steps: 
% (1) build the network
% (2) implemntation of vl_simplenn for updating the network (diff: gradients / fast implementation)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% setup matconvnet


opts.dataDir = 'data/BSDS/';
opts.subset = 300;
opts.expDir = 'data/BSDS/Experiment_diffNet/' ;

opts.lite = false;
opts.numFetchThreads = 0;
opts.augmentation = 0;
opts.train.continue = true;
opts.train.useGpu = true ;
opts.train.prefetch = false;
opts.train.sync = false;
opts.train.conf = 'j2_vgg_fc_toponly';
opts.train.expDir = opts.expDir ;
opts.train.target_layer_id = 26; %14;
[opts,varargin] = vl_argparse(opts, varargin) ;
[opts.train, varargin] = vl_argparse(opts.train, varargin) ;

opts.imgset_train = 'train';
opts.imgset_ho = 'val';

gpuDevice

% -------------------------------------------------------------------------
%                                                    Load former model
% -------------------------------------------------------------------------

rng('default');
rng(0,'twister');
parallel.gpu.rng(0,'CombRecursive');

%if (0)
    cnn_config_diffmap_deepSpect_v4;
   
    %cnn_config_diffmap;
%else
%   cnn_config_diffmap_deepSpect_addStage;
%end
if(0)
    if(0)
        load('/home/jian/Projects/DiffusionMapLearning/data/exp_bake8/net-epoch-100.mat');
        net.layers(end) = [];
        net.layers{end+1} = struct('type', 'neighMasking_v2');
        net.layers{end+1} = struct('type', 'compNormSimiMatrix');
        net.layers{end+1} = struct('type', 'compEigDecomp');
        net.layers{end+1} = struct('type', 'featTransform', 'weights', {{eye(100), 10}}, 'ts', ts); %length(ts)
        net.layers{end+1} = struct('type','compSimiMatrix', 'weights', {{1e+4}});  
        net.layers{end+1} = struct('type', 'Loss');
    else
        load('/home/jian/Projects/DiffusionMapLearning/data/exp_bake8/net-epoch-100.mat');
        net.layers{37}.weights{1} = 1e+3;
        net.layers{36}.weights{2} = 5;
    end     
end

 
imdb.mean_img = mean_img;

if(0)
    opts.train.numEpochs = length(opts.train.learningRate) ;
    opts.cacheDir = [opts.expDir '/masks_' name '/'];
    opts.imgCacheDir = [opts.expDir '/images/']; 
    opts.imdbPath = fullfile(opts.expDir, ['imdb_' opts.imgset_train '_' name '.mat']);
end
%net = net0; 

if(1)
    % reformulate the weight layers of net
    for ll = 1 : length(net.layers)
       % ll
       % if strcmp(net.layers{ll}.type , 'conv') & isfield(net.layers{ll}, 'weights')
       %    net.layers{ll}.filters = net.layers{ll}.weights{1};
       %    net.layers{ll}.biases = net.layers{ll}.weights{2};
       % end

       if strcmp(net.layers{ll}.type , 'pool') 
           net.layers{ll}.pad(:) =0;       
       end
    end


    %imdb = getImdbBSDS(opts);
    if strcmp(opts.train.conf,'none')
      imdb.images.set(imdb.images.set==1)=0;
    end
    %imdb.cacheDir = opts.cacheDir;
    %imdb.imgCacheDir = opts.imgCacheDir;
    imdb.mean_image(1,1,:) = mean_img;
    imdb.expDir = opts.expDir;
    imdb.augmentation = opts.augmentation;
    
    net.layers{24}.pad = [0 1 0 1];
end

imdb.imsizes = [321 481; 481 321]; % this is particular to bsds[size(im, 1), size(im, 2)]; %
for i = 1: size(imdb.imsizes,1)
    imdb.coords{i} = feat_coords(net,imdb.imsizes(i,:), 19); %target_layer_id
end

if(0)
    if opts.augmentation
      getbatch_fun = @(a) getBatchBSDS_v2(imdb,a);
      model_name = [model_name '_aug'];
    else
      getbatch_fun = @(a) getBatchBSDS_v3(imdb,a);
    end

    if opts.subset==500
      model_name = [model_name '_' num2str(opts.subset)]
      imdb.images.set(imdb.images.set==2) = 1;
      imdb.images.set(imdb.images.set==3) = 2;
    else
      model_name
    end
end
% show the config so we know what we did
%vl_simplenn_display(net)

% this fixes the parameters for the feat_coords
net = fix_model_params(net);

% -------------------------------------------------------------------------
%                                               Stochastic gradient descent
% -------------------------------------------------------------------------

% opts_init = opts.train;
% opts_init.learningRate(2:end) = [];
% opts_init.numEpochs = 1;
% for i = 1: 23
%   tmp = load(sprintf('data/BSDS/Experiment_segmentation_bsds/%s_try%d/net-epoch-1.mat',model_name,i),'info');
%   perf(i) = tmp.info.train.error;
% %   [~,info(i)] = cnn_train_segmentation(net, imdb, getbatch_fun, sprintf('%s_try%d',model_name,i), opts_init, 'val', find(imdb.images.set == 2),varargin{:}) ;%,'plotDiagnostics',true
% %   perf(i) = info(i).train.error;
% end
% [~,ii] = max(perf);
% mkdir(sprintf('data/BSDS/Experiment_segmentation_bsds/%s',model_name));
% system(['cp ' sprintf('data/BSDS/Experiment_segmentation_bsds/%s_try%d/net-epoch-1.mat ',model_name,ii), sprintf('data/BSDS/Experiment_segmentation_bsds/%s/net-epoch-1.mat',model_name)]);
% imdb.im = im;
[net, info] = cnn_train_mydiffMap(net, imdb, @getBatch, varargin{:}) ;%,'plotDiagnostics',true
%[net, info] = cnn_train_diffMap(net, imdb, model_name, varargin{:}) ;%,'plotDiagnostics',true
%cnn_train_segmentation

% generate the results 