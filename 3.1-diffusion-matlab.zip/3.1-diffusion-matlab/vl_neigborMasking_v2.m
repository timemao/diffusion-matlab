function y = vl_neigborMasking_v2(x, neighMask, dzdy)
%neighMask(:) = 1;
neighMask = (neighMask * neighMask * neighMask * neighMask * neighMask * neighMask); %
%neighMask = (neighMask * neighMask) > 0;
if nargin <= 2
    try
  y = x .* ((neighMask + neighMask') > 0);
    catch
        x;
    end
else
  y = dzdy .* ((neighMask + neighMask') > 0);
end
