function [y, y1, y2] = vl_nnFeatTransform_v2(x, l ,dzdy) 
weights = l.weights{1};
G = max(diag(real(x{1}.eig.Gamma)), 0);
V = x{1}.eig.V;

ts = l.weights{2}; %gpuArray([0 : 0.1 : 4]);

try
tmp = diag(G .^ ts);
nSele = size(weights, 1);
tmp = tmp(:, 1 : nSele);
Bs = V * tmp;
catch
    tmp;
end
if nargin <= 2  
  y = Bs * weights;
  y1 = [];
  y2 = [];
else
  Gtmp = diag(ts * G .^ (ts-1));
  Gtmp = Gtmp(:, 1 : nSele);  
  
  G2tmp = diag((G.^ts) .* log(G));
  G2tmp = G2tmp(:, 1 : nSele);
  
  y =  {1e+4 * ((Bs' * dzdy)),  1e+4 * sum(sum((V' * dzdy * weights') .* (G2tmp),2))}; 
  y1 = (sum((V' * dzdy * weights') .* (Gtmp),2));  % dzdG
  y2 =  dzdy * (tmp * weights)'; % dzdV
end
