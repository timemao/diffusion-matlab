%addpath(genpath('/home/jian/download_projects/'));
addpath(genpath('/home/jian/Projects/DiffusionMapLearning/external'));
addpath(genpath('./'))
run('/home/jian/download_projects/matconvnet-1.0-beta24/matlab/vl_setupnn.m');
addpath(genpath('/home/jian/download_projects/matconvnet-1.0-beta24/examples'));

%% This function is just for trying some ideas

% Read image
%im = double(imread('/home/jian/Dataset/SiftFlowDataset/Images/spatial_envelope_256x256_static_8outdoorcategories/highway_gre678.jpg'));
%im = double(imread('/media/jian/oldsystem/home/jian/Database/ObjectDiscovery/ObjectDiscovery/ObjectDiscovery-data/Data/MSRC/chair/14_17_s.bmp'));
img = (imread('/media/jian/oldsystem/home/jian/Database/VOC/VOC2012/VOCtrainval/VOCdevkit/VOC2012/JPEGImages/2007_002539.jpg'));

%% Image over-segmentation
% img = imread('bee.jpg');
[labels, numlabels] = slicmex(img,500,20);%numlabels is the same as number of superpixels
%figure, imshow(labels, []);
%figure,imshow(uint8(img))

if(0)
    %% Construct a training set composed of triplets of (img, labels, segms)
    %dataset= ['/home/jian/download_projects/matrix_backprop/data/BSDS/'];
    dataset = ['/media/jian/oldsystem/home/jian/Database/BSR/BSDS500/data/'];
    trainImgFolder = [dataset, 'images/train/'];
    testImgFolder = [dataset, 'images/test/'];
    valImgFolder = [dataset, 'images/val/']

    trainGTFolder = [dataset, 'groundTruth/train/'];
    testGTFolder = [dataset, 'groundTruth/test/'];
    valGTFolder = [dataset, 'groundTruth/val/']

    TrainDataFolder = ['./data/BSDS/train/'];
    TestDataFolder = ['./data/BSDS/test/'];
    valDataFolder = ['./data/BSDS/val/'];

    % For training image set
    trainImgList = dir(trainImgFolder);
    trainGTList = dir(trainGTFolder);
    imdb = [];
    imdb.img_names = [];
    imdb.images.set = [];
    
    len = length(trainImgList);  % number of images
    for l = 3 : len-1
        l
       fname = [trainImgFolder, trainImgList(l).name];
       img = imread(fname);

       lbname = [trainGTFolder, trainGTList(l).name];
       load(lbname);

       % OverSegmentation
       [labels, numlabels] = slicmex(img,500,20);
       
       % Aggregate segms 
       [labels, numlabels] = aggrSegms(img, labels);
       
       % Compute neigbhoring information
       [neig_mask] = getNeigSegmsMask(labels);
       
       gts = groundTruth;
       save([TrainDataFolder, trainImgList(l).name, '.mat'], 'labels', 'numlabels', 'img', 'gts', 'neig_mask');

       imdb.img_names{end+1} = [TrainDataFolder, trainImgList(l).name, '.mat'];
       imdb.images.set(end+1) = 1;
    end
    %save('trainSet_BSDS.mat', 'trainSet');

    % For validation image set
    valImgList = dir(valImgFolder);
    valGTList = dir(valGTFolder);    
    len = length(valImgList);  % number of images
    for l = 3 : len-1
        l
       fname = [valImgFolder, valImgList(l).name];
       img = imread(fname);

       lbname = [valGTFolder, valGTList(l).name];
       load(lbname);

       % OverSegmentation
       [labels, numlabels] = slicmex(img,500,20);
       
       % aggregate segms 
       [labels, numlabels] = aggrSegms(img, labels);
       
       % Compute neigbhoring information
       [neig_mask] = getNeigSegmsMask(labels);
       
       gts = groundTruth;
       
       save([valDataFolder, valImgList(l).name, '.mat'], 'labels', 'numlabels', 'img', 'gts', 'neig_mask');

       imdb.img_names{end+1} = [valDataFolder, valImgList(l).name, '.mat'];
       imdb.images.set(end+1) = 2;
    end
    %save('valSet_BSDS.mat', 'valSet');
    save('imdb_BSDS.mat', 'imdb');
else
    %load('trainSet_BSDS.mat', 'trainSet');
    %load('valSet_BSDS.mat', 'valSet');   
    load('imdb_BSDS.mat');
end

%% Main function for learning Diffusion Distance Net
[net] = cnn_diffMap_deepSpect_v2(imdb);

