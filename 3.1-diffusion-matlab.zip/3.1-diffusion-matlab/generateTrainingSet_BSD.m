load('imdb_BSDS500.mat');
imdb.imsizes = [321 481; 481 321]; % this is particular to bsds[size(im, 1), size(im, 2)]; %
%for i = 1: size(imdb.imsizes,1)
%    imdb.coords{i} = feat_coords(net,imdb.imsizes(i,:), 19);
%    %target_layer_id%
%end

for l = 1 : length(imdb.img_names)
   file = imdb.img_names{l} 
   load(file)
   
   % load image files 
    if(size(img, 3) == 1)
        img = repmat(img, 1, 1, 3);
    end
    [H, W, d] = size(img);
    cind = find(H==imdb.imsizes(:,1)&W==imdb.imsizes(:,2));
    %coor = imdb.coords{cind};
    gt_W = [];
    for id = 1 : length(gts)
        mid = id;
        mask = double(gts{mid}.Segmentation);
    
        [diffDist, prob] = mask2diffDist(mask, labels);
        gt_W{id} = diffDist;
    end
    
    %% re-generate super-pixels guaranteen that each super-pixel contains at least one pixel
    % OverSegmentation
    [labels, numlabels] = slicmex(img,500,20);
       
    % aggregate segms 
    [labels, numlabels] = aggrSegms_deepLab(img, labels);
       
    % Compute neigbhoring information
    [neig_mask] = getNeigSegmsMask(labels);
       
    %gts = groundTruth;
    
    
  % subtract average
  % if isfield(imdb,'mean_image')
  %  im = bsxfun(@minus,double(img),imdb.mean_image);
  % end
  % img_names = imdb.img_names(batch);
  %nc = max(mask(:));
  %ns = size(mask, 1);
  %code = zeros(ns, nc);
  %code(sub2ind([ns, nc], [ones(ns, 1), mask(:)])) = 1;
  
  %img = img; %gpuArray(single(im));
  %data.mask = gpuArray(single(prob));
  %gt_W = gt_W;
  %labels = labels;
  %coor = coor;
  %neig_mask = neig_mask;
  
  [ filepath , name , ext ] = fileparts( file );
  save(['./data/BSDS/ALL_new/',[name, ext]], 'img', 'gt_W', 'labels', 'neig_mask')
    
end