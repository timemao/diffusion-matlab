% This function read the point labels stored using Jason format

datapath1 = '/home/jian/download_projects/whats_the_point/whats_the_point/data/pascal2012_trainval_main.json';
POINTLabels_trainval = loadjson(datapath1);
IDs_trainval = fieldnames(POINTLabels_trainval);
Points_trainval = struct2cell(POINTLabels_trainval);
for l = 1 : length(IDs_trainval)
    fname = ['2', IDs_trainval{l}(7:end)];
    IDs_trainval{l} = fname;
end

datapath2 = '/home/jian/download_projects/whats_the_point/whats_the_point/data/pascal2012_trainval_supp.json';
POINTLabels_supp = loadjson(datapath2);
IDs_supp = fieldnames(POINTLabels_supp);
Points_supp = struct2cell(POINTLabels_supp);
for l = 1 : length(IDs_supp)
    fname = ['2', IDs_supp{l}(7:end)];
    IDs_supp{l} = fname;
end

save('./data/points_labels.mat', 'Points_trainval', 'Points_supp', 'IDs_supp', 'IDs_trainval');