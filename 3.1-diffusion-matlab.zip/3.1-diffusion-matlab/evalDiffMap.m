function pr=evalDiffMap(Prob_filt, segMap, posi_lbs)
lbs=unique(posi_lbs(:, 3));
pr = [];

for p = 1 : length(lbs)
    lb_gt = lbs(p);
    ids = find(posi_lbs(:,3) == lb_gt);
    pos = round(posi_lbs(ids, 1:2));
    %lb_gt = lb; %segMap(pos(1), pos(2));
    lbMap_gt = (segMap == lb_gt);
    lbMap_et = Prob_filt(:,:, lb_gt + 1); %posi_lbs(lb, 3)
    
    %[X1, Y1, T1, AUC] = perfcurve(lbMap_gt(:), lbMap_et(:), 1, 'TVals',0:0.01:1); %'NBoot',1000,
    %Precision = X1 ./ (X1 + Y1);
    %Recall = X1 ./ (X1 + )
    [prec, recall, info] = vl_pr(lbMap_gt(:) - 0.5, lbMap_et(:));
    
    pr{p}.info = info;
    pr{p}.prec = prec;
    pr{p}.recall = recall;
    pr{p}.point = posi_lbs(ids, :);
    
    % compute IOU 
    ths = 0 : 0.05 : 1;
    
    ious = [];
    prec = [];
    rec = [];
    for pp = ths
       ious = [ious, IOU(lbMap_et(:) > pp, lbMap_gt(:))];
       prec = [prec, sum((lbMap_et(:) > pp) .* lbMap_gt(:)) / sum(lbMap_et(:) > pp) ];
       rec = [rec, sum((lbMap_et(:) > pp) .* lbMap_gt(:)) / sum(lbMap_gt(:)) ];
    end
    pr{p}.ious = ious;
    pr{p}.prec = prec;
    pr{p}.rec = rec;
end

function r = IOU(A, O)
r = sum(A .* O) ./ sum(A + O > 0);


%
% figure()
% errorbar(X1(:,1),Y1(:,1),Y1(:,1)-Y1(:,2),Y1(:,3)-Y1(:,1));
% xlim([-0.02,1.02]); ylim([-0.02,1.02]);
% xlabel('False positive rate')
% ylabel('True positive rate')
% title('ROC Curve with Pointwise Confidence Bounds')
% legend('PCBwTA','Location','Best')
