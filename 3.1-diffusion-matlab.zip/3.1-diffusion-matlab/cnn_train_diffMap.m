function [net, info] = cnn_train_diffMap(net, imdb, model_name, varargin)
% CNN_TRAIN   Demonstrates training a CNN
%    CNN_TRAIN() is an example learner implementing stochastic gradient
%    descent with momentum to train a CNN for image classification.
%    It can be used with different datasets by providing a suitable
%    getBatch function.

opts.train = [];
opts.val = [];
opts.numEpochs = 300;
opts.batchSize = 1;
opts.useGpu = true ;
opts.learningRate = 0.001;
opts.continue = false ;
opts.expDir = 'data/exp' ;
opts.conserveMemory = false ;
opts.sync = true ;
opts.prefetch = false;
opts.weightDecay = 0.0005 ;
opts.momentum = 0.9 ;
opts.errorType = 'multiclass' ;
opts.plotDiagnostics = false ;
opts.prependName = '';
opts.schedule.name = 'fixed';
opts.solver = 'adam';
%opts.conf = 'none';
opts.target_layer_id = 0;
opts.testonly = false;
[opts, unrecognized] = vl_argparse(opts, varargin) ;
assert(isempty(unrecognized));


if ~exist(opts.expDir,'dir'), mkdir(opts.expDir) ; end
if isempty(opts.train), opts.train = find(imdb.images.set==1) ; end
if isempty(opts.val), opts.val = find(imdb.images.set==2) ; end
if isnan(opts.train), opts.train = [] ; end

opts

% -------------------------------------------------------------------------
%                                                    Network initialization
% -------------------------------------------------------------------------

for i=1:numel(net.layers)
  if ~strcmp(net.layers{i}.type,'conv'), continue; end
  
  try
  net.layers{i}.filtersMomentum = zeros(size(net.layers{i}.filters), ...
    class(net.layers{i}.filters)) ;
  net.layers{i}.biasesMomentum = zeros(size(net.layers{i}.biases), ...
    class(net.layers{i}.biases)) ; %#ok<*ZEROLIKE>
  catch
      i;
  end
      
  if ~isfield(net.layers{i}, 'filtersLearningRate')
    net.layers{i}.filtersLearningRate = 1 ;
  end
  if ~isfield(net.layers{i}, 'biasesLearningRate')
    net.layers{i}.biasesLearningRate = 1 ;
  end
  if ~isfield(net.layers{i}, 'filtersWeightDecay')
    net.layers{i}.filtersWeightDecay = 1 ;
  end
  if ~isfield(net.layers{i}, 'biasesWeightDecay')
    net.layers{i}.biasesWeightDecay = 1 ;
  end
end

if opts.useGpu
  net = vl_simplenn_move(net, 'gpu') ;
  for i=1:numel(net.layers)
    if ~strcmp(net.layers{i}.type,'conv'), continue; end
    net.layers{i}.filtersMomentum = gpuArray(net.layers{i}.filtersMomentum) ;
    net.layers{i}.biasesMomentum = gpuArray(net.layers{i}.biasesMomentum) ;
  end
end

% -------------------------------------------------------------------------
%                                                        Train and validate
% -------------------------------------------------------------------------
rng('default');
rng(0,'twister');

if opts.useGpu
  one = gpuArray(single(1)) ;
else
  one = single(1) ;
end

info.train.objective = [] ;
info.train.error = [] ;
info.train.topFiveError = [] ;
info.train.speed = [] ;
info.train.covering = [];
info.val.objective = [] ;
info.val.error = [] ;
info.val.topFiveError = [] ;
info.val.speed = [] ;
info.val.covering = [];
info.last_reset = 1;

lr = opts.learningRate(1) ; 
res = [] ;
for epoch=1:opts.numEpochs
  mkdir(fullfile(imdb.expDir,model_name,sprintf('inference_%02d',epoch)));
  
  prevLr = lr ;
  lr = opts.learningRate(epoch);
  
  % fast-forward to where we stopped
  if(~exist(fullfile(opts.expDir, [opts.prependName model_name]),'file'))
    mkdir(fullfile(opts.expDir, [opts.prependName model_name]));
  end

  modelPath = fullfile(opts.expDir, [opts.prependName model_name '/net-epoch-%d.mat']) ;
  modelFigPath = fullfile(opts.expDir, [opts.prependName model_name '/net-train.pdf']) ;
  if opts.continue
    if exist(sprintf(modelPath, epoch),'file')&&~(opts.testonly&&epoch==opts.numEpochs), continue ; end
    if epoch > 1
      if ~opts.testonly
        fprintf('resuming by loading epoch %d\n', epoch-1) ;
        ma = matfile(sprintf(modelPath, epoch-1));
        if isempty(whos(ma,'parallelrngstate'))
          load(sprintf(modelPath, epoch-1), 'net', 'info') ;
        else
          load(sprintf(modelPath, epoch-1), 'net', 'info','rngstate','parallelrngstate') ;
          % restore states so we can continue as if nothing happened
          rng(rngstate);
          parallel.gpu.rng(parallelrngstate);
        end
      else
        if exist(sprintf(modelPath, epoch),'file')
          fprintf('testing by loading epoch %d\n', epoch) ;
          load(sprintf(modelPath, epoch), 'net', 'info') ;
        else
          fprintf('testing by loading epoch %d\n', epoch-1) ;
          load(sprintf(modelPath, epoch-1), 'net', 'info') ;
        end
      end      
    end
  end

  train = opts.train(randperm(numel(opts.train))) ;
  val = opts.val ;

  info.train.objective(end+1) = 0 ;
  info.train.error(end+1) = 0 ;
  info.train.topFiveError(end+1) = 0 ;
  info.train.speed(end+1) = 0 ;
  info.train.predictions = [];
  info.train.targets = [];
  info.train.covering = {};
  info.val.objective(end+1) = 0 ;
  info.val.error(end+1) = 0 ;
  info.val.topFiveError(end+1) = 0 ;
  info.val.speed(end+1) = 0 ;
  info.val.predictions = [];
  info.val.targets = [];
  info.val.covering = {};

  % reset momentum if needed
  if prevLr ~= lr
    fprintf('learning rate changed (%f --> %f): resetting momentum\n', prevLr, lr) ;
    info.last_reset = epoch;
    for l=1:numel(net.layers)
      if ~strcmp(net.layers{l}.type, 'conv'), continue ; end
      net.layers{l}.filtersMomentum = 0 * net.layers{l}.filtersMomentum ;
      net.layers{l}.biasesMomentum = 0 * net.layers{l}.biasesMomentum ;
    end
  end

  n = 0;
  n_train = numel(train);
  res = [];
  for t=1:opts.batchSize:numel(train)
    if opts.testonly
      break;
    end

    % get next image batch and labels
    batch = train(t:min(t+opts.batchSize-1, numel(train))) ;
    % if strcmp(opts.conf(1:min(4,length(opts.conf))),'none') break; end % skip training if there is no model to train
    batch_time = tic ;
    fprintf('training: epoch %02d: processing batch %3d of %3d ...', epoch, ...
            fix(t/opts.batchSize), ceil(numel(train)/opts.batchSize)) ;

    t_get_batch = tic();
    [data] = getBatch(imdb, batch); %[im, mask, diffDist, labels]
    t_batch = toc(t_get_batch);

    if opts.prefetch
      nextBatch = train(t+opts.batchSize:min(t+2*opts.batchSize-1, numel(train)));
      if ~isempty(nextBatch)
        assert(length(imdb.scales)==1);
        img_names = arrayfun(@(x)[sprintf('%s/im_%06d_scale_%d.jpg',imdb.cacheDir,x,imdb.scales(1))],nextBatch,'uniformoutput',false);
        vl_imreadjpeg(img_names);
      end
    end
    if opts.useGpu
       data.im = gpuArray(single(data.im));
       data.mask = gpuArray(single(data.mask));
       data.diffDist = gpuArray(single(data.diffDist));
       data.labels = gpuArray(single(data.labels));
       data.coor = gpuArray(single(data.coor));
    end

    % backprop
    t_process_batch = tic();
    
    res = vl_mysimplenn(net, data, res, one, ...
                        'conserveMemory', opts.conserveMemory, ...
                        'sync', opts.sync);    
    
     % optimization
    %if strcmp(mode, 'train')
    %if ~isempty(parserv), parserv.sync() ; end
    [net, res, info] = accumulateGradients(net, res, info, opts, opts.batchSize, []) ;
    %end
 
    % print information
    batch_time = toc(batch_time) ;
    speed = numel(batch)/batch_time ;
    
    info.train = updateError(imdb, opts, info.train, res, batch_time, batch, masks, epoch, img_names,model_name, orig_masks, frame, im,net) ;

    fprintf(' %.2f s (%.1f images/s)', batch_time, speed) ;
    
    n = t + numel(batch) - 1 ;
    fprintf(' best-cov %.3f mean-cov %.3f obj %.1f', ...
      info.train.error(end)/n, info.train.topFiveError(end)/n, info.train.objective(end)/n) ;
    fprintf('\n') ;

    % debug info
    if opts.plotDiagnostics
      figure(2) ; vl_simplenn_diagnose(net,res) ; drawnow ;
      print(2, [modelFigPath(1:end-13) sprintf('inference_%02d/%03d',epoch,t)], '-dpdf') ;
    end
    res = [];
  end % next batch
  
  % evaluation on validation set
  n_val = numel(val);
  for t=1:opts.batchSize:numel(val)
    batch_time = tic ;
    batch = val(t:min(t+opts.batchSize-1, numel(val))) ;
    fprintf('validation: epoch %02d: processing batch %3d of %3d ...', epoch, ...
            fix(t/opts.batchSize), ceil(numel(val)/opts.batchSize)) ;
    [data] = getBatch(imdb, batch);
    
    if opts.prefetch
      nextBatch = val(t+opts.batchSize:min(t+2*opts.batchSize-1, numel(val))) ;
      if ~isempty(nextBatch)
        assert(length(imdb.scales)==1);
        img_names = arrayfun(@(x)[sprintf('%s/im_%06d_scale_%d.jpg',imdb.cacheDir,x,imdb.scales(1))],nextBatch,'uniformoutput',false);
        vl_imreadjpeg(img_names);
      end
    end
     if opts.useGpu
       data.im = gpuArray(single(data.im));
       data.mask = gpuArray(single(data.mask));
       data.diffDist = gpuArray(single(data.diffDist));
       data.labels = gpuArray(single(data.labels));
       data.coor = gpuArray(single(data.coor));
    end

    % backprop
    t_process_batch = tic();
    
    res = vl_mysimplenn(net, data, res, one, ...
                        'conserveMemory', opts.conserveMemory, ...
                        'sync', opts.sync); 
    
    % print information
    batch_time = toc(batch_time) ;
    speed = numel(batch)/batch_time ;
    
    info.val = updateError(imdb, opts, info.val, res, batch_time, batch, masks, epoch, img_names,model_name, orig_masks, frame, im,net) ;

    fprintf(' %.2f s (%.1f images/s)', batch_time, speed) ;
    n = t + numel(batch) - 1 ;
    fprintf(' best-cov %.3f mean-cov %.3f obj %.1f', ...
      info.val.error(end)/n, info.val.topFiveError(end)/n, info.val.objective(end)/n) ;
    fprintf('\n') ;
  end

  info.train.objective(end) = info.train.objective(end) / n_train;
  info.train.error(end) = info.train.error(end) / n_train;
  info.train.topFiveError(end) = info.train.topFiveError(end) / n_train;
  info.train.speed(end) = numel(train) / info.train.speed(end) ;
  info.val.objective(end) = info.val.objective(end) / n_val;
  info.val.error(end) = info.val.error(end) / n_val;
  info.val.topFiveError(end) = info.val.topFiveError(end) / n_val;
  info.val.speed(end) = numel(val) / info.val.speed(end) ;
  if ~opts.testonly
    rngstate = rng();
    parallelrngstate = parallel.gpu.rng();
    save(sprintf(modelPath,epoch), 'net', 'info', 'opts','rngstate','parallelrngstate','-v7.3') ;
  else
    return;
  end

  figure(1) ; clf ;
  subplot(1,2,1) ;
  semilogy(1:epoch, info.train.objective, 'k') ; hold on ;
  semilogy(1:epoch, info.val.objective, 'b') ;
  xlabel('training epoch') ; ylabel('energy') ;
  grid on ;
  h=legend('train', 'val') ;
  set(h,'color','none');
  title('objective') ;
  subplot(1,2,2) ;
  switch opts.errorType
    case 'sc'
      plot(1:epoch, info.train.error, 'k') ; hold on ;
      plot(1:epoch, info.train.topFiveError, 'k--') ;
      plot(1:epoch, info.val.error, 'b') ;
      plot(1:epoch, info.val.topFiveError, 'b--') ;
      h=legend('train-best','train-avg','val-best','val-avg') ;
  end
  grid on ;
  xlabel('training epoch') ; ylabel('error') ;
  set(h,'color','none') ;
  title('error') ;
  drawnow ;
  if ~opts.testonly
    print(1, modelFigPath, '-dpdf') ;
  end
end

% -------------------------------------------------------------------------
function info = updateError(imdb, opts, info, res_pred, speed,batch,masks ,epoch,img_names,model_name, orig_masks, frame, im,net)
% -------------------------------------------------------------------------
res_obj = res_pred(end).x;
if isempty(res_obj), res_obj = 0; end
batch_size = length(batch);
info.objective(end) = info.objective(end) + sum(double(res_obj)) ;
info.speed(end) = info.speed(end) + speed ;
if isinf(info.objective(end))|| isnan(info.objective(end)) 
  pause;
end

% compute the segmentation itself
net.layers{end-1}.eigspace = 'geig';
net.layers{end-1}.dims = 2:1:14;
if ~isfield(net.layers{end-1},'postproc'), net.layers{end-1}.postproc = 'scc'; end
segm_pred = nnclustering(net.layers{end-1},res_pred(end-1),im);
mask_dims = [size(res_pred(end-2).x,1),size(res_pred(end-2).x,2)];
im_dims = [size(im,1) size(im,2)];
segs = reshape(permute(gather(segm_pred.x),[2 1 3]),[mask_dims(1) mask_dims(2) length(net.layers{end-1}.dims),length(masks)]);
% segs = masks{1};
switch opts.errorType
  case 'sc'
    cind = find(im_dims(1)==imdb.imsizes(:,1)&im_dims(2)==imdb.imsizes(:,2));
    for i = 1: batch_size
      segmentations= zeros(size(orig_masks{i},1),size(orig_masks{i},2),length(net.layers{end-1}.dims));
      covering = zeros(batch_size,length(net.layers{end-1}.dims),size(orig_masks{i},3));
      for j = 1: length(net.layers{end-1}.dims) 
%         seg_orig = zeros(size(im,1),size(im,2));
        % set the
%         for k = -7:8, for l = -7:8, seg_orig(sub2ind(im_dims,imdb.coords{cind}(1,:)+k,imdb.coords{cind}(2,:)+l)) = binary2mask(masks{1},'uint32'); end; end
%         if opts.target_layer_id > 23
%           for k = -7:8, for l = -7:8, seg_orig(sub2ind(im_dims,imdb.coords{cind}(1,:)+k,imdb.coords{cind}(2,:)+l)) = segs(:,:,j,i); end; end
%         else
%           for k = -3:4, for l = -3:4, seg_orig(sub2ind(im_dims,imdb.coords{cind}(1,:)+k,imdb.coords{cind}(2,:)+l)) = segs(:,:,j,i); end; end
%         end
        seg_orig = upsample(segs(:,:,j,i), im_dims, imdb.coords{cind}, im);
        seg_orig = post_process(seg_orig,net.layers{end-1}.postproc);
        seg = zeros(size(orig_masks{i},1),size(orig_masks{i},2)); seg(:) = seg_orig(~frame{i});
        for k = 1:size(orig_masks{i},3)
          covering(i,j,k) = eval_segm(uint32(seg), orig_masks{i}(:,:,k),'sc'); 
        end
        best_covering(i,j) = max(covering(i,j,:));
        mean_covering(i,j) = mean(covering(i,j,:));
        if 0
          addpath ../../o2p-release1/external_src/immerge/
          im = res_pred(1).x;
          myim = uint8(gather(im(:,:,:,i)+110));
          mask = reshape(segm_pred.x(j,:,i),mask_dims); mask = imresize(mask,[size(im,1),size(im,2)],'nearest');
          figure; sc(sc(rgb2gray(myim)).*sc(mask,'jet'))
        end
        segmentations(:,:,j) = seg(:,:);
      end
      seg_cov = covering(i,:,:);
      w = res_pred(end-1).x;
      if opts.testonly
        save(fullfile(imdb.expDir,model_name,sprintf('inference_%02d',epoch),img_names{i}),'segmentations','seg_cov','w');
      end
%       info.topFiveError(end) = info.topFiveError(end) + rank(res_pred(end-1).x(:,:,i),1e-3);
    end
    info.error(end) = info.error(end) + sum(max(best_covering,[],2)) ;
    info.topFiveError(end) = info.topFiveError(end) + sum(max(mean_covering,[],2)) ;
    
    info.covering = [info.covering {covering}];
  otherwise
    error('bad');
end



