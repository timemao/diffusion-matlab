function [lab_filtered, res_eigs] = GenerateInitalLabels_Diff(imgpath, net0, posi_lbs, SegLabels) %iLabels_filt
img = imread(imgpath); 
nCls = 21;

% sepectral clustering
[res_eigs] = cnn_diffMap_apply_v1(img, net0,  size(posi_lbs, 1)+ 2, 1, SegLabels); %length(unique(posi_lbs(:, 3)))
%re = zeros(size(res_eigs.data.labels));
lbs = unique(res_eigs.data.labels(:));
nSPs = size(res_eigs.eig.V, 1);


%figure, subplot(1,4,1); imagesc((img));
%hold on, subplot(1,4,2); imagesc(lbs_spect);

% filtering by spectral bases

diffDist = res_eigs.diffDist;
%Simi = exp(-1e+9 * diffDist);
Simi = diffDist; %res_eigs.simi; %diffDist;

accu_points = zeros(1, nCls);
lab_perPixel_seeds = ones(nSPs, 1);
lab_filtered = zeros(nSPs, nCls);

for k = 1 : size(posi_lbs, 1)
    pt = round(posi_lbs(k, :) + 1);
    if pt(1) <= size(img, 1) & pt(2) <= size(img, 2)
        idSeg = res_eigs.data.labels(round(pt(1)), round(pt(2)));
        lab_perPixel_seeds(idSeg) = pt(3);
        
        try
        accu_points(pt(3)) = accu_points(pt(3)) + 1;
        catch
            pt;
        end
        %try
        lab_filtered(:, pt(3)) = max(lab_filtered(:, pt(3)),Simi(idSeg, :)');
    end
end
lab_perPixel_coarse = lab_perPixel_seeds;    

nlabels = nCls;
onehot_lab = label2onehot(lab_perPixel_coarse, nlabels);
%lab_filtered =  Simi * reshape(onehot_lab, [], nlabels); %Simi
lab_filtered(:, 1) = 0.7; %lab_filtered(:, 1) / (nSPs - size(posi_lbs, 1)) * 1.0;
for k = 2 : size(lab_filtered, 2)
   if accu_points(k) > 0
     lab_filtered(:, k) = lab_filtered(:, k) ;%/ accu_points(k);
   end
end

if(0)
    [~, lab] = max(lab_filtered, [], 2);
    re3 = zeros([prod(size(res_eigs.data.labels)), nCls]);
    for ll = 1 : length(lbs)
       pset = find(res_eigs.data.labels == ll);
       re3(pset, :) = repmat(gather(lab_filtered(ll, :)), length(pset), 1);
    end
    [r,c] = size(res_eigs.data.labels);
    iLabels_filt = reshape(re3, r, c, []);
    [~, lbs_filt] = max(iLabels_filt, [] ,3);
end
    
if(0)
    hold on, subplot(1,4,3); imagesc(lbs_filt);

    re4 = zeros(size(res_eigs.data.labels));
    for ll = 1 : length(lbs)
       re4(find(res_eigs.data.labels == ll)) = gather(lab_perPixel_seeds(ll));
    end
    hold on, subplot(1,4,4); imagesc(re4);
end