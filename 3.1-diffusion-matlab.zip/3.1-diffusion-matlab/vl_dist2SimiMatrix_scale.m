function [y,dw] = vl_dist2SimiMatrix_scale(x,scale,W, dzdy)

[r,d,nimg] = size(x); % each row represents feature vector of a super-pixel.
scale_exp = scale; %exp(scale); %exp(l.weights{1}); %1e+4;
% This function computes the similarity matrix of super-pixels 
x = max(x, 0);
r = size(x, 1);
v1 = ones(r,1);
xv = diag(sqrt(1./(x * v1))); %x * ones(r,1);
vx = diag(sqrt(1./(v1' * x)));
if nargin <= 3
  y = double(exp(-scale_exp * xv * x * vx * r));
  dw = [];  
else
  dzds = (dzdy .* W * (-scale_exp) * r);
  y = -0.5 * (dzds .* ((xv.^3) * x * vx)) * v1 * v1' - 0.5*v1 * v1' * (dzds .* (xv * x * vx.^3)) + xv * dzds * vx;
  dw = sum(sum(dzdy .* (-xv * x * vx) .* W)) * r;
end