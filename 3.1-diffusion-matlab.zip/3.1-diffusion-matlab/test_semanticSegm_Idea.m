close all

nCls = 21;
addpath('/home/jian/download_projects/matconvnet-fcn-master/')
addpath('/home/jian/download_projects/whats-the-point1-master/whats_the_point/whats_the_point/data/');
addpath(genpath('./'))
run('/home/jian/download_projects/matconvnet-1.0-beta24/matlab/vl_setupnn.m');
addpath(genpath('/home/jian/download_projects/matconvnet-1.0-beta24/examples'));

load('/home/jian/Projects/DiffusionMapLearning/data/exp/net-epoch-100.mat'); %exp_bake8/
%load('/home/jian/Projects/DiffusionMapLearning/data/exp/bake_nodropout/net-epoch-40.mat');
net0 = net;
net0 = vl_simplenn_move(net0, 'gpu');

%%%%%%%%%%%%
%load point labels
load('./data/points_labels.mat', 'Points_trainval', 'Points_supp', 'IDs_supp', 'IDs_trainval');
folderpath = '/media/jian/oldsystem/home/jian/Database/VOC/VOC2012/VOCdevkit/VOC2012/JPEGImages/';

imid = 6360;
imgpath = [folderpath, IDs_trainval{imid}, '.jpg'];
posi_lbs = [];
for tt = 1 : length(Points_trainval{imid})
    posi_lbs = [posi_lbs; [Points_trainval{imid}{tt}.y, Points_trainval{imid}{tt}.x, Points_trainval{imid}{tt}.cls]];
end
%%%%%%%%%%%%

%imgpath = '/media/jian/oldsystem/home/jian/Database/Saliency/BenchmarkIMAGES/BenchmarkIMAGES/i40.jpg';
%imgpath = '/media/jian/oldsystem/home/jian/Database/BSR/BSDS500/data/images/train_all/112082.jpg';
img = imread(imgpath); %2007_000175
[iLabels_spect, iLabels_filt] = GenerateInitalLabels_Spect(imgpath, net0, posi_lbs);

Prob_spect = iLabels_spect ./ repmat(sum(iLabels_spect, 3), 1, 1, nCls);
Prob_filt = iLabels_filt ./ repmat(sum(iLabels_filt, 3), 1, 1, nCls);

if(0)
    % output its class labels by fCNN
    res = fcn(imgpath);
%     figure, subplot(1,3,1); imshow(uint8(img)); subplot(1,3,2);imagesc(res.pred); subplot(1,3,3); imagesc(res.pred_LR);

    % sepectral clustering
%     [res_spet, res_eigs] = cnn_diffMap_apply(img, net0, length(unique(posi_lbs(:, 3))) + 1, 1);
%     re = zeros(size(res_eigs.data.labels));
%     lbs = unique(res_eigs.data.labels(:));
%     numCls = length(lbs) + 1;
%     for ll = 1 : length(lbs)
%        re(find(res_eigs.data.labels == ll)) = gather(res_eigs.eig.V(ll, 4));
%     end
%     figure, imagesc(re);
% 
%     % filtering by spectral bases
%     lab_perPixel = res.pred;
%     lab_perPixel_coarse = coarsen(res.pred, gather(res_eigs.data.labels));
%     re2 = zeros(size(res_eigs.data.labels));
%     lbs = unique(res_eigs.data.labels(:));
%     nsegs = length(lbs);
%     [lr, lc] = size(lab_perPixel_coarse);

    if(0)
        lab_perPixel_coarse(lr/2 + 1 : end, :) = 0;
    else
    %     lab_perPixel_seeds = ones(lr,1);
    %     labs = unique(lab_perPixel_coarse(:));
    %     for k = 1 : length(labs)
    %        lb = labs(k) ;
    %        idx = find(lab_perPixel_coarse == lb);
    %        idseed = round(rand(1) * length(idx));
    %        lab_perPixel_seeds(idx(max(1, idseed))) = lb;
    %     end
    %     lab_perPixel_coarse = lab_perPixel_seeds;
        lab_perPixel_seeds = ones(lr,1);
        accu_points = zeros(1, 21);
        for k = 1 : size(posi_lbs, 1)
            idSeg = res_eigs.data.labels(round(posi_lbs(k, 1)), round(posi_lbs(k, 2)));
            lab_perPixel_seeds(idSeg) = posi_lbs(k, 3) + 1;
            accu_points(posi_lbs(k, 3) + 1) = accu_points(posi_lbs(k, 3) + 1) + 1;
        end
        lab_perPixel_coarse = lab_perPixel_seeds;    
    end

    for ll = 1 : length(lbs)
       re2(find(res_eigs.data.labels == ll)) = gather(lab_perPixel_coarse(ll));
    end
    figure, imagesc(re2);

    diffDist = res_eigs.diffDist;

    bases = res_eigs.eig.V;
    %Simi = exp(logm(gather(bases * res_eigs.eig.Gamma * bases')) * 1);
    Simi = exp(-0.5e+9 * diffDist);

    nSimi = diag(1 ./ (sum(Simi, 2))) * Simi;
    [eig2.U, eig2.Gamma, eig2.V] = svd(nSimi);

    bases = eig2.V;
    gamma = (eye(nsegs) - eig2.Gamma) .^ 2;
    lambda = 0.00;
    nlabels = 21;
    onehot_lab = label2onehot(lab_perPixel_coarse, nlabels);
    matDiag =  (1 ./ diag(lambda*gamma + eye(nsegs)));
    %lab_filtered = bases(:, 1 : end) * diag(matDiag(1 : end))* bases(:, 1 : end)' * reshape(onehot_lab, [], nlabels);
    %lab_filtered =  nSimi * reshape(onehot_lab, [], nlabels);
    lab_filtered =  nSimi * reshape(onehot_lab, [], nlabels);
    lab_filtered(:, 1) = lab_filtered(:, 1) / lr * 1.0;
    for k = 2 : size(lab_filtered, 2)
       if accu_points(k) > 0
         lab_filtered(:, k) = lab_filtered(:, k) / accu_points(k);
       end
    end

    %lab_filtered = reshape(lab_filtered, size(lab_perPixel), []);
    [~, lab] = max(lab_filtered, [], 2);
    re3 = zeros(size(res_eigs.data.labels));
    for ll = 1 : length(lbs)
       re3(find(res_eigs.data.labels == ll)) = gather(lab(ll));
    end
    figure, imagesc(re3);


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Generate the initialized labels given the point labels
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end


