%addpath(genpath('/home/jian/download_projects/'));
addpath(genpath('/home/jian/Projects/DiffusionMapLearning/external'));
addpath(genpath('./'))
run('/home/jian/download_projects/matconvnet-1.0-beta24/matlab/vl_setupnn.m');
addpath(genpath('/home/jian/download_projects/matconvnet-1.0-beta24/examples'));

%% This function is just for trying some ideas

% Read image
%im = double(imread('/home/jian/Dataset/SiftFlowDataset/Images/spatial_envelope_256x256_static_8outdoorcategories/highway_gre678.jpg'));
%im = double(imread('/media/jian/oldsystem/home/jian/Database/ObjectDiscovery/ObjectDiscovery/ObjectDiscovery-data/Data/MSRC/chair/14_17_s.bmp'));
img = (imread('/media/jian/oldsystem/home/jian/Database/VOC/VOC2012/VOCtrainval/VOCdevkit/VOC2012/JPEGImages/2007_002539.jpg'));

%% Image over-segmentation
% img = imread('bee.jpg');
[labels, numlabels] = slicmex(img,500,20);%numlabels is the same as number of superpixels
%figure, imshow(labels, []);
%figure,imshow(uint8(img))

load('/home/jian/download_projects/matconvnet-fcn-master/data/fcn8s-voc12_diff_supervised/imdb.mat');

%% Main function for learning Diffusion Distance Net
addpath('/home/jian/download_projects/matconvnet-1.0-beta24/matlab/');
vl_setupnn;
[net] = cnn_diffMap_deepSpect_Sup(imdb);

