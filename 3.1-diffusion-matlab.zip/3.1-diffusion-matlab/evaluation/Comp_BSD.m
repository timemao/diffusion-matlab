%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% This is the function to compare different segmentation methods on 
%% berkeley segmentation database
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% add pathes
addpath(genpath('/home/jian/Projects/DiffusionMapLearning/external'));
addpath(genpath('./'))
run('/home/jian/download_projects/matconvnet-1.0-beta24/matlab/vl_setupnn.m');
addpath(genpath('/home/jian/download_projects/matconvnet-1.0-beta24/examples/'));
addpath('/home/jian/download_projects/matrix_backprop/cnn_seg_release/');
addpath('/home/jian/download_projects/matrix_backprop/myutils');

method = 'DiffMap';
switch method 
    case 'DiffMap'
        % load net
        %load('/home/jian/Projects/DiffusionMapLearning/data/exp/net-epoch-20.mat');
        %load('/home/jian/Projects/DiffusionMapLearning/data/exp_bake8/net-epoch-136.mat');
        %load('/home/jian/Projects/DiffusionMapLearning/data/exp/net-epoch-40.mat');
        %load('/home/jian/Projects/DiffusionMapLearning/data/exp_bake3/net-epoch-11.mat')
        load('/home/jian/Projects/DiffusionMapLearning/data/exp_bake9/net-epoch-100.mat');
        if(0)
            net.layers(end) = [];
            net.layers{end+1} = struct('type', 'neighMasking_v2');
            net.layers{end+1} = struct('type', 'compNormSimiMatrix');
            net.layers{end+1} = struct('type', 'compEigDecomp');
            net.layers{end+1} = struct('type', 'compDiffDist');
            

            net.layers{32}.weights{1} = net.layers{32}.scale;
            %net.layers{32}.weights{2} = net.layers{32}.ts;
            net.layers{37}.weights{1} = net.layers{37}.scale;
            net.layers{36}.weights{2} = net.layers{36}.ts;
        end
        % testing
        net = vl_simplenn_move(net, 'gpu');
        res_lM = cnn_diffMap_BSD(net);
    otherwise
        % load net
        load('/home/jian/download_projects/matrix_backprop/data/BSDS/Experiment_segmentation_bsds/vgg_train_layer_id_26_ncuts_j2_fc_toponly/net-epoch-10.mat');
        cnn_segm_NCuts_BSD(net, 26);
end