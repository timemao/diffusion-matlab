function y = vl_loss_spect(x,gt,dzdy)


% This function computes the diffusion distance over the super-pixels 
si = size(x);
%
%d=length(x);
%x=double(x(:));
no = norm(x);
gt = double(gt); 

E = gt;
W = double(x);
if nargin <= 2
  % compute the projectors
  PiOmega = symmetric(E*pinv(E'*E)*E'); % ok
  %PiW = symmetric(W * pinv(W'*W) * W');
  Wp = pinv(W'*W)*W'; 
  PiW = symmetric(W*Wp);
  y = .5*norm(PiOmega-PiW,'fro')^2;
else
  %Wp = pinv(W);
  %PiW = symmetric(W*Wp); % ok
  Wp = pinv(W'*W) * W';
  PiW =symmetric(W*Wp);
  PiOmega = symmetric(E*pinv(E'*E)*E'); % ok
  y = - 2*(eye(size(W,1))-PiW)*PiOmega*Wp' ; % ok
end


function y = symmetric(W)
y = (W + W') / 2;
