function lab = coarsen(pred, labels)
%Counts = accumarray(labels(:) + 1, ones(size(labels(:))));
%lab = accumarray(labels(:) + 1, reshape(pred, [], 1)) ./ Counts;
lbs = unique(labels);
lab = zeros(length(lbs), 1);
for i = 1 : length(lbs)
   lb = lbs(i);
   idx = find(labels == lb);
   lab(i) = median(pred(idx));    
end
