addpath(genpath('/home/jian/Projects/DiffusionMapLearning/external'));
addpath(genpath('./'))
run('/home/jian/download_projects/matconvnet-1.0-beta24/matlab/vl_setupnn.m');
addpath(genpath('/home/jian/download_projects/matconvnet-1.0-beta24/examples'));

method = 'learnedModel'%'untrained';

if strcmp(method, 'learnedModel')
    %load('/home/jian/Projects/DiffusionMapLearning/data/exp/bake/net-epoch-100.mat');
    %load('/home/jian/Projects/DiffusionMapLearning/data/exp/net-epoch-98.mat'); 
    load('/home/jian/Projects/DiffusionMapLearning/data/exp/net-epoch-spectLoss-50.mat'); 
else
    net = cnn_config_baseline(19);
end
net = vl_simplenn_move(net, 'gpu');

%% Test function for testing the learned model to novel images
%path = '/media/jian/oldsystem/home/jian/Database/ObjectDiscovery/ObjectDiscovery/ObjectDiscovery-data/Data/iCoseg/';
%path = '/media/jian/oldsystem/home/jian/Database/ObjectDiscovery/ObjectDiscovery/ObjectDiscovery-data/Data/MSRC/';
%path = '/media/jian/oldsystem/home/jian/Database/Saliency/microsoft/Image/9/';
%path = '/media/jian/oldsystem/home/jian/Database/VOC/VOC2012/test/VOCdevkit/VOC2012/JPEGImages/';
path = '/media/jian/oldsystem/home/jian/Database/VOC/VOC2012/VOCtrainval/VOCdevkit/VOC2012/JPEGImages/';

img = (imread([ path, '2007_001960.jpg'])); %bike/8_24_s.bmp a path should be placed here
ncls = 3
net.layers(end) = [];
switch method
    case 'learnedModel'
        res_lM = cnn_diffMap_apply(img, net, ncls, 1);
    case 'untrained'
        res_cnn_diffMap_baseline(img, net, 1);
    otherwise
end

figure, subplot(1,3, 1)
imshow(uint8(img + 127));
subplot(1,3,2)
imagesc(res_lM)

%% Comparison to other baseline algorithms
%  Algorithm 1: Matrix backpropatation paper
net_mb = load('/home/jian/download_projects/matrix_backprop/data/BSDS/Experiment_segmentation_bsds/vgg_train_layer_id_26_ncuts_j2_fc_toponly/net-epoch-9.mat');
res_mb = cnn_matBack(img, net_mb.net);
subplot(1,3,3), imagesc(imresize(res_mb(:,:,ncls - 1), [size(img,1), size(img,2)]));

