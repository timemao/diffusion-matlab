function [measures_max, measures_avr] = cnn_diffMap_BSD(net)

% load dataset
dataset= ['/home/jian/download_projects/matrix_backprop/data/BSDS/'];
%testImgFolder = [dataset, 'images/test/'];
%testGTFolder = [dataset, 'groundTruth/test/'];

%testImgList = dir(testImgFolder);
%testGTList = dir(testGTFolder);
saveFolder = ['/home/jian/Projects/DiffusionMapLearning/results/BSD/'];

testImgFolder = [dataset, 'images/val/']; %\val
testGTFolder = [dataset, 'groundTruth/val/']; %\val

testImgList = dir(testImgFolder);
testGTList = dir(testGTFolder);

mean_img = [122.6769, 116.67, 104.0102];
mean_img = reshape(mean_img, 1,1,3);
   
segs = [];groundTruth =[];
for id = 50 : length(testImgList) - 2
    fname = [testImgFolder, testImgList(id + 2).name];
    img = imread(fname);

    lbname = [testGTFolder, testGTList(id + 2).name];
    load(lbname);   
    gt = [];
    for pp = 1 : length(groundTruth)
        gt(:,:,pp) = groundTruth{pp}.Segmentation;
    end
    
    % substract the mean from the input image
    im = bsxfun(@minus,double(img),mean_img);

    % first step: compute supper-pxiels
    [labels, numlabels] = slicmex(img,500,20);
    [labels, numlabels] = aggrSegms(img, labels);
    [neig_mask] = getNeigSegmsMask(labels);

    % second step: construct the input data structure in gpu
    data.labels = gpuArray(single(labels));
    data.im = gpuArray(single(im));
    data.neighMask = gpuArray(single(neig_mask));
    data.imorig = img;

    [r,c,d] = size(data.im);
    idx = [4 : 8 : r-4]';
    idy = [4 : 8 : c-4];
    data.coor = gpuArray(single([reshape(repmat(idx, 1, length(idy)), 1, []); reshape(repmat(idy, length(idx), 1), 1, [])]));

    % Perform net inference on the input data
    res = vl_mysimplenn_diffMap(net, data, [], [], 'disableDropout', 1); %,  'conserveMemory', 'true');    

    % do spectrual clustering after having the spectrals 
    ly_simi = 26 + 7 ; %26
    ly_eig = 28 + 7; %28
    mat_simi = res(33).x;%33, ly_simi
    %mat_simi = exp(-1e+9 * res(end-1).x);
    mat_eig = []; %res(ly_eig +1).x{1}.eig; %

    % return back the result
    segs_all = [];
    for ns = 2 : 7
        opts.dim = ns;
        
        if(1)
            segs = spectClustering(data, mat_simi, mat_eig, opts);
        else
            [re] = myfwkmeans(double(gather([res(37).x])),opts.dim, []); %37
            lbs = unique(data.labels);
            segs = zeros(size(data.labels));
            for ll = 1 : length(lbs)
                segs(find(data.labels == ll)) = gather(re(ll));
            end
            %figure, imagesc(segs);
           % figure,subplot(1,2,1);imshow(uint8(data.im + 127)); subplot(1,2,2);imagesc(segs);
        end
        %
        
        segs = post_process(segs,'scc');
        segs_all{ns - 1} = segs;
        % compute the accuracy
        covering = [];
        for k = 1:size(gt,3)
            %covering = eval_segm(uint32(res{id}), groundTruth(:,:,k),'sc'); 
            covering(k) =  eval_segm(uint32(segs), gt(:,:,k), 'sc'); 
        end
        scores_max(ns, id) = max(covering);
        scores_mean(ns, id) = mean(covering);
    end

    [measures_max(id), idBest_max] = max(scores_max(2:end, id));
    [measures_avr(id), idBest_mean] = max(scores_mean(2:end, id));
    [id, mean(measures_max), mean(measures_avr)]
    
    % save the best results
    sname = [saveFolder, testImgList(id + 2).name, '_diffMAP.mat'];
    re_max = segs_all{idBest_max};
    re_mean = segs_all{idBest_mean};
    accu_max = measures_max(id);
    accu_avr = measures_avr(id);
    save(sname, 're_max', 're_mean', 'accu_max', 'accu_avr', 'img');
    
    
    close all;
end