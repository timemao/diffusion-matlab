% Train_pointSupervise_v2:  Generate the labels for iterative semi-supervise deep learning

% Generate_Labels_Semi_Supervised_voc12_MIOU.m:
        % Generate the whole image label from the given scribble labels for
        % VOC12 dataset
        

% Generate labels for BSD dataset with g.t. labels 

