function [y, y1]=vl_nncompSimi_scale(x, scale, W, dzdy)

[r,d,nimg] = size(x); % each row represents feature vector of a super-pixel.
scale = 1e+1 * r * r;

imgx = double(squeeze(x));
xnorm = sum(imgx .^ 2, 2);
D = (ones(r,1) * xnorm' + xnorm * ones(1, r) - 2 * imgx * imgx');
if nargin <=3
   %y = double(exp(-scale * D));  % L2 distance   
   y = double(exp(-scale * diag(1./(D * ones(r, 1))) * D * diag(1./(ones(r, 1)' * D))));
   y1 = [];
else
   Q = -2 * (dzdy + dzdy') .* W * scale;
   y = cuda_compSimi_backward(double(Q), double(x));
   y1 = sign(sum(sum(dzdy .* (-D) .* exp(-scale * D)))); 
   if abs(y1) / scale < 1e-2
      y1 = y1 * scale / abs(y1) * 1e+2;
   end
   if abs(y1) / scale > 1
      y1 = y1 * scale / abs(y1) *1e+2;
   end
end
     