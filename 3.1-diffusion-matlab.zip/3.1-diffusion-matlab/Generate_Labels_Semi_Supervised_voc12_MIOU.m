%clear all;
close all %clc;
load('/home/jian/download_projects/matconvnet-fcn-master/demo/classes.mat');
load('/home/jian/download_projects/matconvnet-fcn-master/demo/cmap.mat');
clsIdx = 1:numel(classes);
clsMap = containers.Map(classes, clsIdx);


load('/home/jian/download_projects/matconvnet-fcn-master/data/fcn8s-voc12_diffMap/imdb.mat');
%load('/home/jian/download_projects/matconvnet-fcn-master/data/fcn8s-voc12_diffMap/imdb.mat')
load('/home/jian/Projects/DiffusionMapLearning/data/exp/net-epoch-125.mat');

% load network
net0 = net;
net0.layers(end) = [];
%net0.layers{37}.weights{1} = 8;
net0 = vl_simplenn_move(net0, 'gpu');

idset = find(images.set == 2 | images.set == 1);
nimgs = length(idset);
confusion = zeros(21,21);
figure,
for id = 1: 1 : nimgs
    %k = 4788
    try
    k = idset(id)
    name = images.name{k};
    imname = sprintf(paths.image, name);
    
    if(0)
    gtname = sprintf(paths.classSegmentation, name);   
    anno = imread(gtname) ;
    lbmap = single(anno) ;
    lbmap = mod(lbmap + 1, 256) ; % 0 = ignore, 1 = bkg  
    end
    
    % read in the image and the scribble annotation
    im = imread(imname); %'2008_003147.jpg');
    spots = readspots([name,'.xml'], clsMap); %2008_003147
    indx = sub2ind([size(im, 1), size(im, 2)], spots(:,2), spots(:,1));
    cls = spots(:, 3);
    lamap = zeros(size(im, 1), size(im, 2));
    clset = unique(cls);
    for c = 1 : length(clset)
       lamap(indx(find(cls == clset(c)))) = clset(c);
    end
    se = ones(1,1);
    lamap = imdilate(lamap, se);
    subplot(1,3,1);imshow(uint8(im))

    load(images.diffname{k});
    sps = data.labels(find(lamap > 0));
    labs_segs = zeros(size(data.simi, 1), 1);
    labs_segs(sps) = lamap(find(lamap > 0));
    labs = find(lamap > 0);
    subplot(1,3,2), imagesc(reshape(labs_segs(data.labels), size(data.labels)))
    axis image;
   
    data0.im = gpuArray(single(data.im));
    data0.neighMask = gpuArray(single((data.neighMask)));
    data0.labels = gpuArray(single(data.labels));
    data0.coor = gpuArray(single(data.coor));
    res = vl_mysimplenn_TMP(net0, data0, [], []); 
    data.simi_v2 = gather(res(end).x);

    %%% added by Jian

    W = data.simi_v2;  % W = W .* (data.neighMask ^ 5);
    W(W < 0.80)=0;
    sps = unique(sps);
    sps_u = setdiff([1 : size(W,1)], sps);

    D = diag(sum(W,2));
    Du=D(sps_u, sps_u);
    Wu = W(sps_u, sps_u);
    Wul = W(sps_u, sps);

    fl = labs_segs(sps);
    fl_hot = zeros(size(fl, 1), 21);
    fl_hot(sub2ind(size(fl_hot), [1:length(fl)]', fl)) = 1;

    %%%%%%
    
    
    %% 
    %for l = 1 : 100
    %Lap = (reshape(W(data.labels, ), size(data.labels)))
    %%%%%
    %[re, id] = max(W(sps, sps_u), [], 1);
    %re = fl(id);
    %lb(sps) = fl;
    %lb(sps_u) = re;
    
    if(1)
    re = min(max(pinv(Du - Wu + 0 * eye(size(Du))) * Wul * fl_hot, 0), 1); %labs_segs(sps);
    lb_et = [];
    lb_et(sps, :) = fl_hot(:, :);
    lb_et(sps_u, :) = gather(re(:, :));
    [a,lb] = max(lb_et, [], 2);
    lb(find(a < 0.05)) = 1;
    
    else
    label_hot = zeros(size(W, 1), 21);
    label_hot(sps, :) = fl_hot;
    mask = zeros(size(W, 1), 1);
    mask(sps) = 1;
    lambda = 1e-2;
    L =  (D - W); %diag(1 ./ diag(D)) *
    re = (lambda * L + diag(mask) + 1e-8 * eye(size(D))) \ (diag(mask) * label_hot);
    %re = pinv(Du - Wu + 0 * eye(size(Du))) * Wul * [1,0, 0]';
    [a,lb] = max(re, [], 2);
    
    lb(find(a < 0.15)) = 1;
    lb(sps) = fl;
    end
    lb_et_map = reshape(lb(data.labels), size(data.labels));
  
    list = unique(lb_et_map);
    for l = 1 : length(list)
        lbcurr = list(l);
        conn = bwconncomp(gather(lb_et_map == lbcurr));
        for pp = 1 : conn.NumObjects
            if isempty(find(lamap(conn.PixelIdxList{pp}) == lbcurr))
                lb_et_map(conn.PixelIdxList{pp}) = 1;
            end
        end
    end
    subplot(1,3,3); imagesc(lb_et_map)
    axis image;
    
    if(0)
    %%% Accumulate accuracy
    ok = lbmap > 0 ;
    confusion = confusion + gather(accumarray([lbmap(ok),lb_et_map(ok)],1,[21 21]));
    [info.iu, info.miu, info.pacc, info.macc] = getAccuracies(confusion) ;
    info.id = k;
    info
    end
   % close all
    %%%
    if(0)
    % begin to visualize the scribbles
    numScribble = numel(unique(spots(:, 4)));
    clsScribble = unique(spots(:, 3));
    clsScribble = [clsScribble ones(numel(clsScribble), 1)];
    him = image(im);
    set(him, 'AlphaData', 0.5);
    hold on;
    axis off;
    for ii = 1:numScribble
        scribble = spots(spots(:, 4) == ii, :);
        plot(scribble(:, 1), scribble(:, 2), 'Color', cmap(scribble(1, 3), :), ...
            'LineWidth', 3);
        idx = find(clsScribble(:, 1) == scribble(1, 3));
        if clsScribble(idx, 2) == 1
    %         meanX = round(mean(scribble(:, 1)));
    %         meanY = round(mean(scribble(:, 2)));
            text(scribble(1, 1)+5, scribble(1, 2)+5, classes{scribble(1, 3)}, 'Color', ...
                [0 0 0], 'FontSize', 13);
            clsScribble(idx, 2) = 0;
        end
    end
    end
    
    data_info.lb_et_map = lb_et_map;
    data_info.imname = name;
    data_info.simi = data.simi_v2;
    data_info.seg = data.labels;
    %save(['./data/VOC2012_Train_Labels_DIFF/', name, '.mat'], 'data_info');
    
    end
end
    