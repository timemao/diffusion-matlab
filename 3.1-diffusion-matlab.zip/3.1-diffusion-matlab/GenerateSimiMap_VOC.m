%% This function learn for semantic segmentation with the weak point-wise supervision
close all

%nCls = 21;
addpath('/home/jian/download_projects/matconvnet-fcn-master/')
%addpath('/home/jian/download_projects/whats-the-point1-master/whats_the_point/whats_the_point/data/');
%addpath(genpath('./'))
%run('/home/jian/download_projects/matconvnet-1.0-beta24/matlab/vl_setupnn.m');
addpath(genpath('/home/jian/download_projects/matconvnet-1.0-beta24/examples'));
%addpath('/home/jian/download_projects/vlfeat-master/toolbox');

%% Step 1: generate the initial labels given the weak point-wise supervisions
load('/home/jian/Projects/DiffusionMapLearning/data/exp/net-epoch-110.mat');
net0 = net;
net0.layers(end) = [];
net0 = vl_simplenn_move(net0, 'gpu');

%%%%%%%%%%%%
%load point labels
folderpath = '/media/jian/oldsystem/home/jian/Database/VOC/VOC2012/VOCdevkit/VOC2012/JPEGImages/';
foldersegm_gt = '/media/jian/oldsystem/home/jian/Database/VOC/VOC2012/VOCdevkit/VOC2012/SegmentationClass/';
savefolder = '/home/jian/Projects/DiffusionMapLearning/data/VOC_point/';

load('/home/jian/download_projects/matconvnet-fcn-master/data/fcn8s-voc12_diffMap/imdb.mat')
list_file = dir(foldersegm_gt);
pr = [];
for k = 700: length(images.name)
    k
    try
    load(images.diffname{k});
    
    data0.im = gpuArray(single(data.im));
    data0.neighMask = gpuArray(single((data.neighMask)));
    data0.labels = gpuArray(single(data.labels));
    data0.coor = gpuArray(single(data.coor));
    
    % perform testing
    res = vl_mysimplenn_TMP(net0, data0, [], []); 
    
    data.simi_v2 = gather(res(end).x);
    save(images.diffname{k}, 'data');
    end
end