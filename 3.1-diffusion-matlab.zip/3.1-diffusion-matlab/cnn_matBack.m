function res = cnn_matBack(img, net, ncls)

addpath('/home/jian/download_projects/matrix_backprop/cnn_seg_release');

mean_img = [122.6769, 116.67, 104.0102];
mean_img = reshape(mean_img, 1,1,3);
im = bsxfun(@minus,double(img),mean_img);

data.im = gpuArray(single(im));
data.imorig = img;
res_pred = vl_mysimplenn_matBP2(net, data.im, [], [], [], 'disableDropout', true, 'conserveMemory', 0);

[segm_pred, eigens, Gs] = mynnclustering(net.layers{end-1},res_pred(end),img);
mask_dims = [size(res_pred(end-2).x,1),size(res_pred(end-2).x,2)];
%im_dims = [size(imdb.im,1) size(imdb.im,2)];%
segs = permute(gather(segm_pred.x),[2 1 3]);
segs = reshape(segs, mask_dims(1), mask_dims(2), []);
eigens = reshape(eigens, mask_dims(1), mask_dims(2), []);

res = segs;